<div class="<?php print "block block-$block->module" ?>" id="<?php print "block-$block->module-$block->delta"; ?>">
  <h2><?php print $block->subject ?></h2>
  <div class="content"><?php print $block->content ?></div>
</div>
