<?php

define('HEADING_TITLE', 'NewsDesk ... administraci�n de art�culos y categor�as');
define('HEADING_TITLE_SEARCH', 'Buscar:');
define('HEADING_TITLE_GOTO', 'Ir a:');

define('TABLE_HEADING_ID', 'ID');
define('TABLE_HEADING_CATEGORIES_newsdesk', 'Categor�as / Noticias');
define('TABLE_HEADING_DATE', 'Fecha');
define('TABLE_HEADING_ACTION', 'Accci�n');
define('TABLE_HEADING_STATUS', 'Estado');

define('IMAGE_NEW_STORY', 'Nuevo art�culo');

define('TEXT_CATEGORIES', 'Categor�as:');
define('TEXT_SUBCATEGORIES', 'Subcategor�as:');
define('TEXT_NEWSDESK', 'Noticias:');
define('TEXT_NEW_NEWSDESK', 'Art�culos en la categor�a &quot;%s&quot;');

define('TABLE_HEADING_LATEST_NEWS_HEADLINE', 'T�tular');
define('TEXT_NEWS_ITEMS', 'Art�culos:');
define('TEXT_INFO_HEADING_DELETE_ITEM', 'Borrar elemento');
define('TEXT_DELETE_ITEM_INTRO', 'Est�s seguro de querer borrar este elemento?');

define('TEXT_LATEST_NEWS_HEADLINE', 'Titular:');
define('TEXT_NEWSDESK_CONTENT', 'Contenido:');

define('IMAGE_NEW_NEWS_ITEM', 'Nuevo art�culo');

define('TEXT_NEWSDESK_STATUS', 'Estado del art�culo:');
define('TEXT_NEWSDESK_DATE_AVAILABLE', 'Fecha de disponibilidad:');
define('TEXT_NEWSDESK_AVAILABLE', 'Visible');
define('TEXT_NEWSDESK_NOT_AVAILABLE', 'No visible');

define('TEXT_NEWSDESK_URL', 'URL externa:');
define('TEXT_NEWSDESK_URL_WITHOUT_HTTP', '<small>(sin http://)</small>');
define('TEXT_NEWSDESK_URL_NAME', 'Nombre del acoplamiento del URL:');

define('TEXT_NEWSDESK_SUMMARY', 'Sumario:');
define('TEXT_NEWSDESK_CONTENT', 'Contenido:');
define('TEXT_NEWSDESK_HEADLINE', 'Titular:');

define('TEXT_NEWSDESK_DATE_AVAILABLE', 'Disponible:');
define('TEXT_NEWSDESK_DATE_ADDED', 'Este art�culo fue emitido el:');

define('TEXT_NEWSDESK_ADDED_LINK_HEADER', "Este es el link que has a�adido:");
define('TEXT_NEWSDESK_ADDED_LINK', '<a href="http://%s" target="blank"><u>' . $newslink . '</u></a>');

define('TEXT_NEWSDESK_ADDED_LINK_HEADER_NAME', "�ste es el nombre de acoplamiento que usted ha agregado:");
define('TEXT_NEWSDESK_ADDED_LINK_NAME', '<a href="http://%s" target="blank"><u>link name</u></a>');

define('TEXT_NEWSDESK_PRICE_INFO', 'Precio:');
define('TEXT_NEWSDESK_TAX_CLASS', 'Impuestos:');
define('TEXT_NEWSDESK_AVERAGE_RATING', 'Puntuaci�n media:');
define('TEXT_NEWSDESK_QUANTITY_INFO', 'Cantidad:');
define('TEXT_DATE_ADDED', 'A�adido el:');
define('TEXT_DATE_AVAILABLE', 'Fecha de disponibilidad:');
define('TEXT_LAST_MODIFIED', '�ltima modificaci�n:');
define('TEXT_IMAGE_NONEXISTENT', 'NO EXISTE IMAGEN');
define('TEXT_NO_CHILD_CATEGORIES_OR_story', 'Inserta una nueva categor�a o noticia en<br>&nbsp;<br><b>%s</b>');

define('TEXT_EDIT_INTRO', 'Haz los cambios necesarios');
define('TEXT_EDIT_CATEGORIES_ID', 'ID categor�a:');
define('TEXT_EDIT_CATEGORIES_NAME', 'Nombre de la categor�a:');
define('TEXT_EDIT_CATEGORIES_IMAGE', 'Imagen de la categor�a:');
define('TEXT_EDIT_SORT_ORDER', 'Orden:');

define('TEXT_INFO_COPY_TO_INTRO', 'Escoje una nueva categor�a a la que quieres copiar el art�culo');
define('TEXT_INFO_CURRENT_CATEGORIES', 'Categor�as actuales:');

define('TEXT_INFO_HEADING_NEW_CATEGORY', 'Nueva categor�a');
define('TEXT_INFO_HEADING_EDIT_CATEGORY', 'Editar categor�a');
define('TEXT_INFO_HEADING_DELETE_CATEGORY', 'Borrar categor�a');
define('TEXT_INFO_HEADING_MOVE_CATEGORY', 'Mover categor�a');
define('TEXT_INFO_HEADING_DELETE_NEWS', 'Borrar noticias');
define('TEXT_INFO_HEADING_MOVE_NEWS', 'Mover noticias');
define('TEXT_INFO_HEADING_COPY_TO', 'Copiar a');

define('TEXT_DELETE_CATEGORY_INTRO', 'Quieres borrar esta categor�a?');
define('TEXT_DELETE_PRODUCT_INTRO', 'Quieres borrar definitivamente esta noticia?');

define('TEXT_DELETE_WARNING_CHILDS', '<b>ATENCI�N:</b> Hay %s (sub)categor�as en esta categor�a!');
define('TEXT_DELETE_WARNING_NEWSDESK', '<b>ATENCI�N:</b> Hay %s art�culos en esta categor�a!');

define('TEXT_MOVE_NEWSDESK_INTRO', 'Selecciona en qu� categor�a quieres colocar <b>%s</b>');
define('TEXT_MOVE_CATEGORIES_INTRO', 'Selecciona en qu� categor�a quieres colocar <b>%s</b>');
define('TEXT_MOVE', 'Mover <b>%s</b> a:');

define('TEXT_NEW_CATEGORY_INTRO', 'Rellena la informaci�n de la nueva categor�a');
define('TEXT_CATEGORIES_NAME', 'Nombre de la categor�a:');
define('TEXT_CATEGORIES_IMAGE', 'Imagen de la categor�a:');
define('TEXT_SORT_ORDER', 'Orden:');

define('EMPTY_CATEGORY', 'Categor�a vac�a');

define('TEXT_HOW_TO_COPY', 'Modo de copia:');
define('TEXT_COPY_AS_LINK', 'Enlazar art�culo');
define('TEXT_COPY_AS_DUPLICATE', 'Duplicar art�culo');

define('ERROR_CANNOT_LINK_TO_SAME_CATEGORY', 'Error: No se pueden enalazar art�culos bajo un misma categor�a.');
define('ERROR_CATALOG_IMAGE_DIRECTORY_NOT_WRITEABLE', 'Error: El directorio de im�genes no tiene permisos de escritura: ' . DIR_FS_CATALOG_IMAGES);
define('ERROR_CATALOG_IMAGE_DIRECTORY_DOES_NOT_EXIST', 'Error: El directorio de im�genes no existe: ' . DIR_FS_CATALOG_IMAGES);

define('TEXT_NEWSDESK_START_DATE', 'Start Date:');
define('TEXT_DATE_FORMAT', 'Date formated as:');

define('TEXT_SHOW_STATUS', 'Estado');

define('TEXT_DELETE_IMAGE', 'Borrar imagen ?');
define('TEXT_DELETE_IMAGE_INTRO', 'CUIDADO: Borrando esta imagen la eliminar�s completamente. Si quieres hacerlo - Est�s advertido !!');

define('TEXT_NEWSDESK_STICKY', 'Art�culo fijo');
define('TEXT_NEWSDESK_STICKY_ON', 'SI');
define('TEXT_NEWSDESK_STICKY_OFF', 'NO');
define('TABLE_HEADING_STICKY', 'Fijado');

define('TEXT_NEWSDESK_IMAGE', 'Im�gen(es) del art�culo:');

define('TEXT_NEWSDESK_IMAGE_ONE', 'Imagen 1:');
define('TEXT_NEWSDESK_IMAGE_TWO', 'Imagen 2:');
define('TEXT_NEWSDESK_IMAGE_THREE', 'Imagen 3:');

define('TEXT_NEWSDESK_IMAGE_SUBTITLE', 'Introduzca un t�tulo para la imagen 1:');
define('TEXT_NEWSDESK_IMAGE_SUBTITLE_TWO', 'Introduzca un t�tulo para la imagen 2:');
define('TEXT_NEWSDESK_IMAGE_SUBTITLE_THREE', 'Introduzca un t�tulo para la imagen 3:');

define('TEXT_NEWSDESK_IMAGE_PREVIEW_ONE', 'Imagen n�mero 1 del art�culo:');
define('TEXT_NEWSDESK_IMAGE_PREVIEW_TWO', 'Imagen n�mero 2 del art�culo:');
define('TEXT_NEWSDESK_IMAGE_PREVIEW_THREE', 'Imagen n�mero 3 del art�culo:');

/*

	osCommerce, Open Source E-Commerce Solutions ---- http://www.oscommerce.com
	Copyright (c) 2002 osCommerce
	Released under the GNU General Public License

	IMPORTANT NOTE:

	This script is not part of the official osC distribution but an add-on contributed to the osC community.
	Please read the NOTE and INSTALL documents that are provided with this file for further information and installation notes.

	script name:			NewsDesk
	version:        		1.48.2
	date:       			06-05-2004 (dd/mm/yyyy)
	original author:		Wolfen aka 241
	web site:       		www..com
	modified code by:		Wolfen aka 241

*/
?>