<?php
/*
  $Id: affiliate_contact.php,v 1.1.1.1 2004/03/04 23:40:10 ccwjr Exp $

  OSC-Affiliate
  
  Contribution based on:
  
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Enviar Email a Afiliados');

define('TEXT_AFFILIATE', 'Afiliado:');
define('TEXT_SUBJECT', 'Asunto:');
define('TEXT_FROM', 'Desde:');
define('TEXT_MESSAGE', 'Mensaje:');
define('TEXT_SELECT_AFFILIATE', 'Seleccionar Afiliado');
define('TEXT_ALL_AFFILIATES', 'Todos los Afiliados');
define('TEXT_NEWSLETTER_AFFILIATES', 'Todos los Suscritos');

define('NOTICE_EMAIL_SENT_TO', 'Aviso: Email enviado a: %s');
define('ERROR_NO_AFFILIATE_SELECTED', 'Error: No ha seleccionado Afiliado.');
?>