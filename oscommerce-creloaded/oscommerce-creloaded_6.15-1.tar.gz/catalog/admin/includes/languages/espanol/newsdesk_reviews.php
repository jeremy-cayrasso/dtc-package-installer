<?php

define('HEADING_TITLE', 'Comentarios de art�culos');

define('TABLE_HEADING_PRODUCTS', 'Art�culos');
define('TABLE_HEADING_RATING', 'Puntuaci�n');
define('TABLE_HEADING_DATE_ADDED', 'A�adido');
define('TABLE_HEADING_ACTION', 'Acci�n');

define('ENTRY_PRODUCT', 'Art�culo:');
define('ENTRY_FROM', 'Autor:');
define('ENTRY_DATE', 'Fecha:');
define('ENTRY_REVIEW', 'Comentario:');
define('ENTRY_REVIEW_TEXT', '<small><font color="#ff0000"><b>NOTA:</b></font></small>&nbsp;no se traduce HTML!&nbsp;');
define('ENTRY_RATING', 'Puntuaci�n:');

define('TEXT_INFO_DELETE_REVIEW_INTRO', 'Quieres realmente borrar este comentario?');

define('TEXT_INFO_DATE_ADDED', 'A�adido:');
define('TEXT_INFO_LAST_MODIFIED', '�ltima modificaci�n:');
define('TEXT_INFO_IMAGE_NONEXISTENT', 'NO EXISTE IMAGEN');
define('TEXT_INFO_REVIEW_AUTHOR', 'Autor:');
define('TEXT_INFO_REVIEW_RATING', 'Puntuaci�n:');
define('TEXT_INFO_REVIEW_READ', 'Lecturas:');
define('TEXT_INFO_REVIEW_SIZE', 'Tama�o:');
define('TEXT_INFO_PRODUCTS_AVERAGE_RATING', 'Puntuaci�n media:');

define('TEXT_OF_5_STARS', '%s de 5 estrellas!');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>BUENA</b></font></small>');
define('TEXT_BAD', '<small><font color="#ff0000"><b>MALA</b></font></small>');
define('TEXT_INFO_HEADING_DELETE_REVIEW', 'Borrar comentario');

define('TEXT_IMAGE_NONEXISTENT', 'NO EXISTE IMAGEN');

define('TEXT_APPROVED', 'Aprovado') ;
define('TEXT_APPROVE', 'Aprobar') ;
define('TEXT_DISAPPROVE', 'Desaprobar') ;
define('TEXT_YES', 'Si') ;
define('TEXT_NO', 'No') ;

/*

	osCommerce, Open Source E-Commerce Solutions ---- http://www.oscommerce.com
	Copyright (c) 2002 osCommerce
	Released under the GNU General Public License

	IMPORTANT NOTE:

	This script is not part of the official osC distribution but an add-on contributed to the osC community.
	Please read the NOTE and INSTALL documents that are provided with this file for further information and installation notes.

	script name:			NewsDesk
	version:        		1.48.2
	date:       			14-05-2004 (dd/mm/yyyy)
	original author:		Carsten aka moyashi
	web site:       		www..com
	modified code by:		Wolfen aka 241

*/
?>