<?php

define('HEADING_TITLE', 'FAQ Reviews');

define('TABLE_HEADING_PRODUCTS', 'FAQS');
define('TABLE_HEADING_RATING', 'Rating');
define('TABLE_HEADING_DATE_ADDED', 'Date Added');
define('TABLE_HEADING_ACTION', 'Action');

define('ENTRY_PRODUCT', 'FAQ:');
define('ENTRY_FROM', 'From:');
define('ENTRY_DATE', 'Date:');
define('ENTRY_REVIEW', 'Review:');
define('ENTRY_REVIEW_TEXT', '<small><font color="#ff0000"><b>NOTE:</b></font></small>&nbsp;HTML is not translated!&nbsp;');
define('ENTRY_RATING', 'Rating:');

define('TEXT_INFO_DELETE_REVIEW_INTRO', 'Are you sure you want to delete this review?');

define('TEXT_INFO_DATE_ADDED', 'Date Added:');
define('TEXT_INFO_LAST_MODIFIED', 'Last Modified:');
define('TEXT_INFO_IMAGE_NONEXISTENT', 'IMAGE DOES NOT EXIST');
define('TEXT_INFO_REVIEW_AUTHOR', 'Author:');
define('TEXT_INFO_REVIEW_RATING', 'Rating:');
define('TEXT_INFO_REVIEW_READ', 'Read:');
define('TEXT_INFO_REVIEW_SIZE', 'Size:');
define('TEXT_INFO_PRODUCTS_AVERAGE_RATING', 'Average Rating:');

define('TEXT_OF_5_STARS', '%s of 5 Stars!');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>GOOD</b></font></small>');
define('TEXT_BAD', '<small><font color="#ff0000"><b>BAD</b></font></small>');
define('TEXT_INFO_HEADING_DELETE_REVIEW', 'Delete Review');

define('TEXT_IMAGE_NONEXISTENT', 'IMAGE DOES NOT EXIST');

define('TEXT_APPROVED', 'Approved') ;
define('TEXT_APPROVE', 'Approve') ;
define('TEXT_DISAPPROVE', 'Disapprove') ;
define('TEXT_YES', 'Yes') ;
define('TEXT_NO', 'No') ;


/*

	osCommerce, Open Source E-Commerce Solutions ---- http://www.oscommerce.com
	Copyright (c) 2002 osCommerce
	Released under the GNU General Public License

	IMPORTANT NOTE:

	This script is not part of the official osC distribution but an add-on contributed to the osC community.
	Please read the NOTE and INSTALL documents that are provided with this file for further information and installation notes.

	script name:	FaqDesk
	version:		1.2.5
	date:			2003-09-01
	author:			Carsten aka moyashi
	web site:		www..com

*/
?>