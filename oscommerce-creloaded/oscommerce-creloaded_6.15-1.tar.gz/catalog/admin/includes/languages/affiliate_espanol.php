<?php
/*
  $Id: affiliate_espanol.php,v 1.1.1.1 2004/03/04 23:40:00 ccwjr Exp $

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

// reports box text in includes/boxes/affiliate.php
define('BOX_HEADING_AFFILIATE', 'Afiliados');
define('BOX_AFFILIATE_SUMMARY', 'Resumen');
define('BOX_AFFILIATE', 'Afiliados');
define('BOX_AFFILIATE_PAYMENT', 'Pago');
define('BOX_AFFILIATE_BANNERS', 'Banners');
define('BOX_AFFILIATE_CONTACT', 'Contactenos');
define('BOX_AFFILIATE_SALES', 'Ventas');
define('BOX_AFFILIATE_CLICKS', 'Clicks');
?>
