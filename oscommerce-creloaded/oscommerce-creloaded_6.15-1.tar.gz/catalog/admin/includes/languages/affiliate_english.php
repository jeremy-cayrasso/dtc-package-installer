<?php
/*
  $Id: affiliate_english.php,v 1.2 2004/03/05 00:36:41 ccwjr Exp $

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

// reports box text in includes/boxes/affiliate.php
define('BOX_HEADING_AFFILIATE', 'Affiliates');
define('BOX_AFFILIATE_SUMMARY', 'Summary');
define('BOX_AFFILIATE', 'Affiliates');
define('BOX_AFFILIATE_PAYMENT', 'Payment');
define('BOX_AFFILIATE_BANNERS', 'Banners');
define('BOX_AFFILIATE_CONTACT', 'Contact');
define('BOX_AFFILIATE_SALES', 'Sales');
define('BOX_AFFILIATE_CLICKS', 'Clicks');
?>
