<?php
/*
  $Id: affiliate_german.php,v 1.2 2004/03/05 00:36:41 ccwjr Exp $

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

// reports box text in includes/boxes/affiliate.php
define('BOX_HEADING_AFFILIATE', 'Partnerprogramm');
define('BOX_AFFILIATE_SUMMARY', 'Zusammenfassung');
define('BOX_AFFILIATE', 'Partner');
define('BOX_AFFILIATE_PAYMENT', 'Provisionszahlungen');
define('BOX_AFFILIATE_BANNERS', 'Banner');
define('BOX_AFFILIATE_CONTACT', 'Kontakt');
define('BOX_AFFILIATE_SALES', 'Partner Verk&auml;ufe');
define('BOX_AFFILIATE_CLICKS', 'Klicks');
?>
