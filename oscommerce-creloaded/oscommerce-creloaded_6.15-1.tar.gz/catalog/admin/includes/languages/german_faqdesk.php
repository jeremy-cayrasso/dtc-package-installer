<?php
//BEGIN -- faqdesk
define('BOX_HEADING_FAQDESK', 'FAQDesk');
define('BOX_FAQDESK', 'FAQ Verwaltung');
define('BOX_FAQDESK_REVIEWS', 'Bewertungen Verwaltung');

define('FAQDESK_ARTICLES', 'FAQS');
define('FAQDESK_REVIEWS', 'Bewertungen');
//END -- faqdesk





/*

	osCommerce, Open Source E-Commerce Solutions ---- http://www.oscommerce.com
	Copyright (c) 2002 osCommerce
	Released under the GNU General Public License

	IMPORTANT NOTE:

	This script is not part of the official osC distribution but an add-on contributed to the osC community.
	Please read the NOTE and INSTALL documents that are provided with this file for further information and installation notes.

	script name:	FaqDesk
	version:		1.2.5
	date:			2003-09-01
	author:			Carsten aka moyashi
	web site:		www..com

*/
?>
