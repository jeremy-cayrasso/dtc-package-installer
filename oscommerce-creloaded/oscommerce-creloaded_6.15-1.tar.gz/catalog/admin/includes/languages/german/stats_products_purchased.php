<?php
/*
  $Id: stats_products_purchased.php,v 1.2 2004/03/05 00:36:42 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Meistverkaufte Artikel');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_PRODUCTS', 'Artikel');
define('TABLE_HEADING_PURCHASED', 'verkaufte Anzahl');
?>