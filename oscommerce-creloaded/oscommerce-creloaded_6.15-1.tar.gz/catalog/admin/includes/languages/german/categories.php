<?php
/*
  $Id: categories.php,v 1.3 2004/03/15 12:13:02 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

// BOF MaxiDVD: Added For Ultimate-Images Pack!
define('TEXT_PRODUCTS_IMAGE_NOTE','<b>Artikel Bild:</b><small><br> Hauptbild benutzt in den <br><u>Katalog und Beschreibung</u> Seiten.<small>');
define('TEXT_PRODUCTS_IMAGE_MEDIUM', '<b>Gr&ouml;sseres Bild:</b><br><small> ERSETZT Kleines Bild in der <br><u>Produktbeschreibungs</u>-Seite.</small>');
define('TEXT_PRODUCTS_IMAGE_LARGE', '<b>Pop-up Bild:</b><br><small>ERSETZT Kleines Bild in der <br><u>Pop-up Fenster</u> Seite.</small>');
define('TEXT_PRODUCTS_IMAGE_LINKED', '<u>Speichere Artikel, die dieses Bild gemeinsam nutzen =</u>');
define('TEXT_PRODUCTS_IMAGE_REMOVE', '<b>Entferne</b> dieses Bild von diesem Artikel?');
define('TEXT_PRODUCTS_IMAGE_DELETE', '<b>L&ouml;sche</b> dieses Bild vom Server (Dauerhaft!)?');
define('TEXT_PRODUCTS_IMAGE_REMOVE_SHORT', 'Entfernen');
define('TEXT_PRODUCTS_IMAGE_DELETE_SHORT', 'L&ouml;schen');
define('TEXT_PRODUCTS_IMAGE_TH_NOTICE', '<b>SM = Kleine Bilder</b> (<b>SM</b>all). Wenn ein "SM" Bild benutzt wird,<br>(Allein) wird KEIN Pop-up Fenster Link erzeugt, das "SM" Bild<br> wird direkt unter der <br>Produktbeschreibung<br> platziert. <br>Wenn gemeinsam mit einem <br>"XL" Bild rechts verwendet, wird ein Pop-Up Fenster-Link<br>erzeugt, und das "XL" Bild wird in <br>einem Pop-up Fenster gezeigt.<br><br>');
define('TEXT_PRODUCTS_IMAGE_XL_NOTICE', '<b>XL = Grosse Bilder</b> (<b>XL</b>arge). Werden f�r das Pop-up Fenster-Bild benutzt<br><br><br>');
define('TEXT_PRODUCTS_IMAGE_ADDITIONAL', 'Zus&auml;tzliche Bilder - Diese erscheinen unter dem Artikel, falls verwendet.');
define('TEXT_PRODUCTS_IMAGE_SM_1', 'SM Bild 1:');
define('TEXT_PRODUCTS_IMAGE_XL_1', 'XL Bild 1:');
define('TEXT_PRODUCTS_IMAGE_SM_2', 'SM Bild 2:');
define('TEXT_PRODUCTS_IMAGE_XL_2', 'XL Bild 2:');
define('TEXT_PRODUCTS_IMAGE_SM_3', 'SM Bild 3:');
define('TEXT_PRODUCTS_IMAGE_XL_3', 'XL Bild 3:');
define('TEXT_PRODUCTS_IMAGE_SM_4', 'SM Bild 4:');
define('TEXT_PRODUCTS_IMAGE_XL_4', 'XL Bild 4:');
define('TEXT_PRODUCTS_IMAGE_SM_5', 'SM Bild 5:');
define('TEXT_PRODUCTS_IMAGE_XL_5', 'XL Bild 5:');
define('TEXT_PRODUCTS_IMAGE_SM_6', 'SM Bild 6:');
define('TEXT_PRODUCTS_IMAGE_XL_6', 'XL Bild 6:');
// EOF MaxiDVD: Added For Ultimate-Images Pack!

define('HEADING_TITLE', 'Kategorien / Artikel');
define('HEADING_TITLE_SEARCH', 'Suche: ');
define('HEADING_TITLE_GOTO', 'Gehe zu:');

define('TABLE_HEADING_ID', 'ID');
define('TABLE_HEADING_CATEGORIES_PRODUCTS', 'Kategorien / Artikel');
define('TABLE_HEADING_ACTION', 'Aktion');
define('TABLE_HEADING_STATUS', 'Status');

define('TEXT_NEW_PRODUCT', 'Neuer Artikel in &quot;%s&quot;');
define('TEXT_CATEGORIES', 'Kategorien:');
define('TEXT_SUBCATEGORIES', 'Unterkategorien:');
define('TEXT_PRODUCTS', 'Artikel:');
define('TEXT_PRODUCTS_PRICE_INFO', 'Preis:');
define('TEXT_PRODUCTS_TAX_CLASS', 'Steuerklasse:');
define('TEXT_PRODUCTS_AVERAGE_RATING', 'durchschnittl. Bewertung:');
define('TEXT_PRODUCTS_QUANTITY_INFO', 'Anzahl:');
define('TEXT_DATE_ADDED', 'hinzugef&uuml;gt am:');
define('TEXT_DELETE_IMAGE', 'Bild l&ouml;schen');

define('TEXT_DATE_AVAILABLE', 'Erscheinungsdatum:');
define('TEXT_LAST_MODIFIED', 'letzte &Auml;nderung:');
define('TEXT_IMAGE_NONEXISTENT', 'BILD EXISTIERT NICHT');
define('TEXT_NO_CHILD_CATEGORIES_OR_PRODUCTS', 'Bitte f&uuml;gen Sie eine neue Kategorie oder einen Artikel ein.');
define('TEXT_PRODUCT_MORE_INFORMATION', 'F&uuml;r weitere Informationen, besuchen Sie bitte die <a href="http://%s" target="blank"><u>Homepage</u></a> des Herstellers.');
define('TEXT_PRODUCT_DATE_ADDED', 'Diesen Artikel haben wir am %s in unseren Katalog aufgenommen.');
define('TEXT_PRODUCT_DATE_AVAILABLE', 'Dieser Artikel ist erh&auml;ltlich ab %s.');

define('TEXT_EDIT_INTRO', 'Bitte f&uuml;hren Sie alle notwendigen &Auml;nderungen durch.');
define('TEXT_EDIT_CATEGORIES_ID', 'Kategorie ID:');
define('TEXT_EDIT_CATEGORIES_NAME', 'Kategorie Name:');
define('TEXT_EDIT_CATEGORIES_IMAGE', 'Kategorie Bild:');
define('TEXT_EDIT_SORT_ORDER', 'Sortierreihenfolge:');
define('TEXT_EDIT_CATEGORIES_HEADING_TITLE', 'Kategorien-&Uuml;berschrifts-Titel:');
define('TEXT_EDIT_CATEGORIES_DESCRIPTION', 'Kategorien-&Uuml;berschrifts-Beschreibung:');

define('TEXT_INFO_COPY_TO_INTRO', 'Bitte w&auml;hlen Sie eine neue Kategorie aus, in die Sie den Artikel kopieren m&ouml;chten:');
define('TEXT_INFO_CURRENT_CATEGORIES', 'aktuelle Kategorien:');

define('TEXT_INFO_HEADING_NEW_CATEGORY', 'Neue Kategorie');
define('TEXT_INFO_HEADING_EDIT_CATEGORY', 'Kategorie bearbeiten');
define('TEXT_INFO_HEADING_DELETE_CATEGORY', 'Kategorie l&ouml;schen');
define('TEXT_INFO_HEADING_MOVE_CATEGORY', 'Kategorie verschieben');
define('TEXT_INFO_HEADING_DELETE_PRODUCT', 'Artikel l&ouml;schen');
define('TEXT_INFO_HEADING_MOVE_PRODUCT', 'Artikel verschieben');
define('TEXT_INFO_HEADING_COPY_TO', 'Kopieren nach');

define('TEXT_DELETE_CATEGORY_INTRO', 'Sind Sie sicher, dass Sie diese Kategorie l&ouml;schen m&ouml;chten?');
define('TEXT_DELETE_PRODUCT_INTRO', 'Sind Sie sicher, dass Sie diesen Artikel l&ouml;schen m&ouml;chten?');

define('TEXT_DELETE_WARNING_CHILDS', '<b>WARNUNG:</b> Es existieren noch %s (Unter-)Kategorien, die mit dieser Kategorie verbunden sind!');
define('TEXT_DELETE_WARNING_PRODUCTS', '<b>WARNING:</b> Es existieren noch %s Artikel, die mit dieser Kategorie verbunden sind!');

define('TEXT_MOVE_PRODUCTS_INTRO', 'Bitte w&auml;hlen Sie die &uuml;bergordnete Kategorie, in die Sie <b>%s</b> verschieben m&ouml;chten');
define('TEXT_MOVE_CATEGORIES_INTRO', 'Bitte w&auml;hlen Sie die &uuml;bergordnete Kategorie, in die Sie <b>%s</b> verschieben m&ouml;chten');
define('TEXT_MOVE', 'Verschiebe <b>%s</b> nach:');

define('TEXT_NEW_CATEGORY_INTRO', 'Bitte geben Sie die neue Kategorie mit allen relevanten Daten ein.');
define('TEXT_CATEGORIES_NAME', 'Kategorie Name:');
define('TEXT_CATEGORIES_IMAGE', 'Kategorie Bild:');
define('TEXT_SORT_ORDER', 'Sortierreihenfolge:');

define('TEXT_PRODUCTS_STATUS', 'Artikelstatus:');
define('TEXT_PRODUCTS_DATE_AVAILABLE', 'Erscheinungsdatum:');
define('TEXT_PRODUCT_AVAILABLE', 'auf Lager');
define('TEXT_PRODUCT_NOT_AVAILABLE', 'nicht vorr&auml;tig');
define('TEXT_PRODUCTS_MANUFACTURER', 'Artikel-Hersteller:');
define('TEXT_PRODUCTS_NAME', 'Artikelname:');
define('TEXT_PRODUCTS_DESCRIPTION', 'Artikelbeschreibung:');
define('TEXT_PRODUCTS_QUANTITY', 'Artikelanzahl:');
define('TEXT_PRODUCTS_MODEL', 'Artikel-Nr.:');
define('TEXT_PRODUCTS_IMAGE', 'Artikelbild:');
define('TEXT_PRODUCTS_URL', 'Herstellerlink:');
define('TEXT_PRODUCTS_URL_WITHOUT_HTTP', '<small>(ohne f&uuml;hrendes http://)</small>');
define('TEXT_PRODUCTS_PRICE_NET', 'Artikelpreis (Netto):');
define('TEXT_PRODUCTS_PRICE_GROSS', 'Artikelpreis (Brutto):');
define('TEXT_PRODUCTS_WEIGHT', 'Artikelgewicht:');
define('TEXT_NONE', '--keines--');

define('EMPTY_CATEGORY', 'Leere Kategorie');

define('TEXT_HOW_TO_COPY', 'Kopiermethode:');
define('TEXT_COPY_AS_LINK', 'Artikel verlinken');
define('TEXT_COPY_AS_DUPLICATE', 'Artikel duplizieren');

define('ERROR_CANNOT_LINK_TO_SAME_CATEGORY', 'Fehler: Artikel k&ouml;nnen nicht in der gleichen Kategorie verlinkt werden.');
define('ERROR_CATALOG_IMAGE_DIRECTORY_NOT_WRITEABLE', 'Fehler: Das Verzeichnis \'images\' im Katalogverzeichnis ist schreibgesch&uuml;tzt: ' . DIR_FS_CATALOG_IMAGES);
define('ERROR_CATALOG_IMAGE_DIRECTORY_DOES_NOT_EXIST', 'Fehler: Das Verzeichnis \'images\' im Katalogverzeichnis ist nicht vorhanden: ' . DIR_FS_CATALOG_IMAGES);
define('ERROR_CANNOT_MOVE_CATEGORY_TO_PARENT', 'Fehler: Kategorie kann nicht in eine Sub-Kategurie verschoben werden');

//Header Tags Controller Admin
define('TEXT_PRODUCTS_PAGE_TITLE', 'Artikelseite Titel:');
define('TEXT_PRODUCTS_HEADER_DESCRIPTION', 'Artikel Header Beschreibung:');
define('TEXT_PRODUCTS_KEYWORDS', 'Artikel Keywords:');
?>
