<?php
/*
  $Id: salemaker.php,v 1.2 2004/03/15 12:13:02 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'SaleMaker');

define('TABLE_HEADING_SALE_NAME', 'Abverkauf Name');
define('TABLE_HEADING_SALE_DEDUCTION', 'Nachlass');
define('TABLE_HEADING_SALE_DATE_START', 'Startdatum');
define('TABLE_HEADING_SALE_DATE_END', 'Enddatum');
define('TABLE_HEADING_STATUS', 'Status');
define('TABLE_HEADING_ACTION', 'Aktion');

define('TEXT_SALEMAKER_NAME', 'Abverkauf Name:');
define('TEXT_SALEMAKER_DEDUCTION', 'Nachlass:');
define('TEXT_SALEMAKER_DEDUCTION_TYPE', '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Typ:&nbsp;&nbsp;');
define('TEXT_SALEMAKER_PRICERANGE_FROM', 'Artikel Preisspanne:');
define('TEXT_SALEMAKER_PRICERANGE_TO', '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bis&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;');
define('TEXT_SALEMAKER_SPECIALS_CONDITION', 'Wenn ein Artikel ein Angebot ist:');
define('TEXT_SALEMAKER_DATE_START', 'Startdatum:');
define('TEXT_SALEMAKER_DATE_END', 'Enddatum:');
define('TEXT_SALEMAKER_CATEGORIES', '<b>Oder</b> W&auml;hlen Sie die Kategorien aus, f�r welche dieser Abverkauf gilt:');
define('TEXT_SALEMAKER_POPUP', '<a href="javascript:session_win();"><span class="errorText"><b>klicken Sie hier f&uuml;r weitere SaleMaker Tipps.</b></span></a>');
define('TEXT_SALEMAKER_IMMEDIATELY', 'per Sofort');
define('TEXT_SALEMAKER_NEVER', 'Nie');
define('TEXT_SALEMAKER_ENTIRE_CATALOG', 'W&auml;hlen Sie diese Box wenn der Abverkauf f&uuml;r <b>Alle Artikel</b> gelten soll:');
define('TEXT_SALEMAKER_TOP', 'Gesamter Katalog');

define('TEXT_INFO_DATE_ADDED', 'Hinzugef&uuml;gt am:');
define('TEXT_INFO_DATE_MODIFIED', 'Zuletzt ge&auml;ndert:');
define('TEXT_INFO_DATE_STATUS_CHANGE', 'Letzte Status &Auml;nderung:');
define('TEXT_INFO_SPECIALS_CONDITION', 'Angebote Kondition:');
define('TEXT_INFO_DEDUCTION', 'Nachlass:');
define('TEXT_INFO_PRICERANGE_FROM', 'Preisspanne:');
define('TEXT_INFO_PRICERANGE_TO', ' bis ');
define('TEXT_INFO_DATE_START', 'Startet:');
define('TEXT_INFO_DATE_END', 'Endet:');

define('SPECIALS_CONDITION_DROPDOWN_0', 'Angebots-Preis Ignorieren');
define('SPECIALS_CONDITION_DROPDOWN_1', 'Abverkaufs-Kondition Ignorieren');
define('SPECIALS_CONDITION_DROPDOWN_2', 'Abverkaufsnachlass am Angebots-Preis anwenden');

define('DEDUCTION_TYPE_DROPDOWN_0', 'Nachlass-Wert');
define('DEDUCTION_TYPE_DROPDOWN_1', 'Prozent');
define('DEDUCTION_TYPE_DROPDOWN_2', 'Neuer Preis');

define('TEXT_INFO_HEADING_COPY_SALE', 'Abverkauf kopieren');
define('TEXT_INFO_COPY_INTRO', 'Neuer Name f�r die Kopie von<br>&nbsp;&nbsp;"%s"');

define('TEXT_INFO_HEADING_DELETE_SALE', 'Abverkauf l&ouml;schen');
define('TEXT_INFO_DELETE_INTRO', 'Sind Sie sicher, dass Sie diesen Abverkauf dauerhaft l&ouml;schen wollen?');
?>