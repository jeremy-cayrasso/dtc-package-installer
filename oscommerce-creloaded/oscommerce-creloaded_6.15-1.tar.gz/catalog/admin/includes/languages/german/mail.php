<?php
/*
  $Id: mail.php,v 1.3 2004/03/15 12:13:02 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Email an Kunden versenden');

define('TEXT_CUSTOMER', 'Kunde:');
define('TEXT_SUBJECT', 'Betreff:');
define('TEXT_FROM', 'Absender:');
define('TEXT_MESSAGE', 'Nachricht:');
define('TEXT_SELECT_CUSTOMER', 'Kunden ausw&auml;hlen');
define('TEXT_ALL_CUSTOMERS', 'Alle Kunden');
define('TEXT_NEWSLETTER_CUSTOMERS', 'An alle Newsletter-Abonnenten');

define('NOTICE_EMAIL_SENT_TO', 'Hinweis: Email wurde versendet an: %s');
define('ERROR_NO_CUSTOMER_SELECTED', 'Fehler: Es wurde kein Kunde ausgew&auml;hlt.');
// MaxiDVD Added Line For WYSIWYG HTML Area: BOF
define('TEXT_EMAIL_BUTTON_TEXT', '<p><HR><b><font color="red">Der Zur�ck Button ist ABGESCHALTEN, w�hrend der HTML WYSIWYG Editor EINGESCHALTEN ist,</b></font> WARUM? - Weil wenn Sie den Zur�ck Button klicken, w�hrend Sie Ihr HTML Email editieren, das PHP (php.ini - "Magic Quotes = On") automatisch "\\\\\\\" backslashes erstellt, wo Anf�hrungszeichen " erscheinen (HTML benutzt diese in Links, Bildern usw.) und das st�rt das HTML, die Bilder werden verschwinden wenn Sie die Email nocheinmal best�tigen. Wenn Sie den WYSIWYG Editor im Admin-Men� abschalten, wird die HTML-F�higkeit von osCommerce auch ABGESCHALTEN und der Zur�ck-Button wird wieder erscheinen. Eine Abhilfe f�r dieses PHP/HTML Problem w�re klasse, wenn jemand eine L�sung daf�r kennt.<br><br><b>Wenn Sie wirklich hre Emails vor dem Absenden nocheinmal ansehen m�ssen, benutzen Sie den "Vorschau" Button im WYSIWYG Editor.<br><HR>');
define('TEXT_EMAIL_BUTTON_HTML', '<p><HR><b><font color="red">HTML ist im Moment Abgeschaltet!</b></font><br><br>Wenn Sie eine HTML-Email versenden wollen, schalten Sie den WYSIWYG-Editor for Email in: Admin-->Configuration-->WYSIWYG Editor-->Optionen ein.<br>');
// MaxiDVD Added Line For WYSIWYG HTML Area: EOF
?>