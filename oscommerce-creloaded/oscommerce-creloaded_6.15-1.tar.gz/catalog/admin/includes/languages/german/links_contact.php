<?php
/*
  $Id: links_contact.php,v 1.2 2004/03/05 00:36:42 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Email an Link Partner senden');

define('TEXT_LINK_PARTNER', 'Link Partner:');
define('TEXT_SUBJECT', 'Betreff:');
define('TEXT_FROM', 'Von:');
define('TEXT_MESSAGE', 'Nachricht:');
define('TEXT_SELECT_LINK_PARTNER', 'Link Partner ausw&auml;hlen');
define('TEXT_ALL_LINK_PARTNERS', 'Alle Link Partner');

define('NOTICE_EMAIL_SENT_TO', 'Hinweis: Email gesendet an: %s');
define('ERROR_NO_LINK_PARTNER_SELECTED', 'Fehler: Es w�rde kein Link Partner ausgew&auml;hlt.');
?>
