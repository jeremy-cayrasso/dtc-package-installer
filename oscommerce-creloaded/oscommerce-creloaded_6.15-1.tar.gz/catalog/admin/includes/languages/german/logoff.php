<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Abmelden');
define('NAVBAR_TITLE', 'Abmelden');
define('TEXT_MAIN', 'Sie wurden erfolgreich aus dem <b>Admin</b> Bereich abgemeldet. Es ist nun ungef&auml;hrlich, den Computer zu verlassen. Klicken Sie Zur�ck, um sich erneut anzumelden');
define('TEXT_RELOGIN', 'Erneut anmelden');
?>
