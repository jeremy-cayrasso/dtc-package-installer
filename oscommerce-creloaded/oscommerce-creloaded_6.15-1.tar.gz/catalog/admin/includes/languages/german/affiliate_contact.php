<?php
/*
  $Id: affiliate_contact.php,v 1.2 2004/03/05 00:36:42 ccwjr Exp $

  OSC-Affiliate
  
  Contribution based on:
  
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Email an Partner versenden');

define('TEXT_AFFILIATE', 'Partner:');
define('TEXT_SUBJECT', 'Betreff:');
define('TEXT_FROM', 'Absender:');
define('TEXT_MESSAGE', 'Nachricht:');
define('TEXT_SELECT_AFFILIATE', 'Partner ausw&auml;hlen');
define('TEXT_ALL_AFFILIATES', 'Alle Partner');
define('TEXT_NEWSLETTER_AFFILIATES', 'An alle Partner-Newsletter Abonnenten');

define('NOTICE_EMAIL_SENT_TO', 'Hinweis: Email wurde versendet an: %s');
define('ERROR_NO_AFFILIATE_SELECTED', 'Fehler: Es wurde kein Partner ausgew&auml;hlt.');
?>