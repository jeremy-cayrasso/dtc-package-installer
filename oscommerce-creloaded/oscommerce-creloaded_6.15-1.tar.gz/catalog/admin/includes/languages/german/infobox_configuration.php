<?php
/*
  $Id: infobox_configuration.php,v 1.2 2004/03/05 00:36:42 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/


define('HEADING_TITLE', 'Infobox Anzeigen, Erstellen und Update');
define('TABLE_HEADING_INFOBOX_FILE_NAME', 'Titel');
define('TABLE_HEADING_ACTIVE', 'Box aktivieren?');
define('TABLE_HEADING_KEY', 'Box Heading definieren');
define('TABLE_HEADING_ACTION', 'Aktion');
define('TABLE_HEADING_COLUMN', 'Spalte w&auml;hlen');
define('TABLE_HEADING_SORT_ORDER', 'Position');
define('TABLE_HEADING_TEMPLATE', 'Box Template');
define('TABLE_HEADING_FONT_COLOR', 'Font Farbe');

define('TEXT_INFO_EDIT_INTRO', 'Bitte f&uuml;hren Sie notwendige &Auml;nderungen durch');
define('TEXT_INFO_DATE_ADDED', 'Hinzugef�gt:');
define('TEXT_INFO_LAST_MODIFIED', 'Zuletzt ge&auml;ndert:');
define('TEXT_INFO_HEADING_NEW_INFOBOX', 'Neue Infobox erstellen');
define('TEXT_INFO_INSERT_INTRO', 'Ein Beispiel f�r die<b> what\'s_new.php</b> Infobox ist ausgew&auml;hlt');
define('TEXT_INFO_DELETE_INTRO', '<P STYLE="color: red; font-weight: bold;">Best&auml;tigen Sie OKum die Infobox zu l&ouml;schen');
define('TEXT_INFO_HEADING_DELETE_INFOBOX', 'Infobox l&ouml;schen?');
define('TEXT_INFO_HEADING_UPDATE_INFOBOX', 'Infobox updaten');

define('IMAGE_INFOBOX_STATUS_GREEN', 'Links');
define('IMAGE_INFOBOX_STATUS_GREEN_LIGHT', 'Links setzen');
define('IMAGE_INFOBOX_STATUS_RED', 'Rechts');
define('IMAGE_INFOBOX_STATUS_RED_LIGHT', 'Rechts setzen');

define('BOX_HEADING_BOXES', 'Boxen Admin');

define('JS_BOX_HEADING', '* Der \'Define Key\' Eintrag muss abgeschlossen werden. Beispiel: BOX_HEADING_WHATS_NEW\n');
define('JS_INFO_BOX_HEADING', '* Der \'Box heading\' Eintrag muss abgeschlossen werden.\n');
define('JS_BOX_LOCATION', '* Sie m&uuml;ssen eine Spalte ausw&auml;hlen, um Ihre Infobox anzuzeigen\n');
define('JS_INFO_BOX_FILENAME', '* Sie m&uuml;ssen einen Dateinamen f&uuml;r Ihre Infobox festlegen\n');
?>