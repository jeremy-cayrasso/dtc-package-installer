<?php

define('HEADING_TITLE', 'FAQDesk ... Kategorie- und FAQ-Management');
define('HEADING_TITLE_SEARCH', 'Suche:');
define('HEADING_TITLE_GOTO', 'Gehe zu:');

define('TABLE_HEADING_ID', 'ID');
define('TABLE_HEADING_CATEGORIES_FAQDESK', 'Frage');
define('TABLE_HEADING_ACTION', 'Aktion');
define('TABLE_HEADING_STATUS', 'Status');

define('IMAGE_NEW_STORY', 'Neue FAQ');

define('TEXT_CATEGORIES', 'Kategorien:');
define('TEXT_SUBCATEGORIES', 'Subkategorien:');
define('TEXT_FAQDESK', 'FAQs:');
define('TEXT_NEW_FAQDESK', 'FAQs in der Kategorie &quot;%s&quot;');

define('TABLE_HEADING_LATEST_NEWS_HEADLINE', '&Uuml;berschrift');
define('TEXT_NEWS_ITEMS', 'FAQs:');
define('TEXT_INFO_HEADING_DELETE_ITEM', 'Beitrag l&ouml;schen');
define('TEXT_DELETE_ITEM_INTRO', 'Sind Sie sicher, dass Sie diesen Beitrag dauerhaft l&ouml;schen wollen?');

define('TEXT_LATEST_NEWS_HEADLINE', 'Frage:');
define('TEXT_FAQDESK_ANSWER_LONG', 'Lange Antwort:');

define('IMAGE_NEW_NEWS_ITEM', 'Neue FAQ');

define('TEXT_FAQDESK_STATUS', 'FAQ Status:');
define('TEXT_FAQDESK_DATE_AVAILABLE', 'Datum verf&uuml;gbar:');
define('TEXT_FAQDESK_AVAILABLE', 'Verf&uuml;gbar');
define('TEXT_FAQDESK_NOT_AVAILABLE', 'Nicht verf&uuml;gbar');

define('TEXT_FAQDESK_URL', 'Extra URL:');
define('TEXT_FAQDESK_URL_WITHOUT_HTTP', '<small>(ohne http://)</small>');

define('TEXT_FAQDESK_ANSWER_SHORT', 'Kurze Antwort:');
define('TEXT_FAQDESK_ANSWER_LONG', 'Lange Antwort:');
define('TEXT_FAQDESK_QUESTION', 'Frage:');

define('TEXT_FAQDESK_DATE_AVAILABLE', 'Startdatum:');
define('TEXT_FAQDESK_DATE_ADDED', 'Diese FAQ wurde eingegeben am:');

define('TEXT_FAQDESK_ADDED_LINK_HEADER', "Das ist der Link, den Sie hinzugef&uuml;gt haben:");
define('TEXT_FAQDESK_ADDED_LINK', '<a href="http://%s" target="blank"><u>Webseite</u></a>');

define('TEXT_FAQDESK_AVERAGE_RATING', 'Durchschnittliche Bewertung:');
define('TEXT_DATE_ADDED', 'Hinzugef&uuml;gt am:');
define('TEXT_DATE_AVAILABLE', 'Datum verf&uuml;gbar:');
define('TEXT_LAST_MODIFIED', 'Zuletz ge&auml;ndert:');
define('TEXT_IMAGE_NONEXISTENT', 'BILD IST NICHT VORHANDEN');
define('TEXT_NO_CHILD_CATEGORIES_OR_story', 'Bitte f�gen Sie eine neue Kategorie oder FAQ ein, in<br>&nbsp;<br><b>%s</b>');

define('TEXT_EDIT_INTRO', 'Bitte f�hren Sie notwendige &Auml;nderungen durch');
define('TEXT_EDIT_CATEGORIES_ID', 'Kategorie ID:');
define('TEXT_EDIT_CATEGORIES_NAME', 'Kategorie Name:');
define('TEXT_EDIT_CATEGORIES_DESCRIPTION', 'Kategorie Beschreibung:');
define('TEXT_EDIT_CATEGORIES_IMAGE', 'Kategorie Bild:');
define('TEXT_EDIT_SORT_ORDER', 'Sortierreihenfolge:');

define('TEXT_INFO_COPY_TO_INTRO', 'Bitte w�hlen Sie eine neue Kategorie in die Sie diese diese FAQ kopieren wollen');
define('TEXT_INFO_CURRENT_CATEGORIES', 'Derzeitige Kategorien:');

define('TEXT_INFO_HEADING_NEW_CATEGORY', 'Neue Kategorie');
define('TEXT_INFO_HEADING_EDIT_CATEGORY', 'Kategorie editieren');
define('TEXT_INFO_HEADING_DELETE_CATEGORY', 'Kategorie l&ouml;schen');
define('TEXT_INFO_HEADING_MOVE_CATEGORY', 'Kategorie verschieben');
define('TEXT_INFO_HEADING_DELETE_NEWS', 'FAQ l&ouml;schen');
define('TEXT_INFO_HEADING_MOVE_NEWS', 'FAQ verschieben');
define('TEXT_INFO_HEADING_COPY_TO', 'Kopieren nach');

define('TEXT_DELETE_CATEGORY_INTRO', 'Sind Sie sicher, dass Sie diese Kategorie l&ouml;schen wollen?');
define('TEXT_DELETE_PRODUCT_INTRO', 'Sind Sie sicher, dass Sie diese FAQ dauerhaft l&ouml;schen wollen?');

define('TEXT_DELETE_WARNING_CHILDS', '<b>WARNUNG:</b> Es sind immer noch %s (Sub-)Kategorien zu dieser Kategorie verlinkt!');
define('TEXT_DELETE_WARNING_FAQDESK', '<b>WARNUNG:</b> Es sind immer noch %s FAQS zu dieser Kategorie verlinkt!');

define('TEXT_MOVE_FAQDESK_INTRO', 'Bitte w&auml;hlen Sie die Kategorie aus, in der <b>%s</b> liegen soll');
define('TEXT_MOVE_CATEGORIES_INTRO', 'Bitte w&auml;hlen Sie die Kategorie aus, in der <b>%s</b> liegen soll');
define('TEXT_MOVE', 'Move <b>%s</b> to:');

define('TEXT_NEW_CATEGORY_INTRO', 'Bitte geben Sie folgende Informationen zur neuen Kategorie an');
define('TEXT_CATEGORIES_NAME', 'Kategorie Name:');
define('TEXT_CATEGORIES_DESCRIPTION_NAME', 'Kategorie Beschreibung:');
define('TEXT_CATEGORIES_IMAGE', 'Kategorie Bild:');
define('TEXT_SORT_ORDER', 'Sortierreihenfolge:');

define('EMPTY_CATEGORY', 'Leere Kategorie');

define('TEXT_HOW_TO_COPY', 'Kopier-Methode:');
define('TEXT_COPY_AS_LINK', 'Link FAQ');
define('TEXT_COPY_AS_DUPLICATE', 'Dupliziere FAQ');

define('ERROR_CANNOT_LINK_TO_SAME_CATEGORY', 'Fehler: Kann FAQs nicht in derselben Kategorie verlinken.');
define('ERROR_CATALOG_IMAGE_DIRECTORY_NOT_WRITEABLE', 'Fehler: Catalog images Verzeichnis ist nicht beschreibbar: ' . DIR_FS_CATALOG_IMAGES);
define('ERROR_CATALOG_IMAGE_DIRECTORY_DOES_NOT_EXIST', 'Fehler: Catalog images Verzeichnis ist nicht vorhanden: ' . DIR_FS_CATALOG_IMAGES);

define('TEXT_FAQDESK_START_DATE', 'Startdatum:');
define('TEXT_DATE_FORMAT', 'Datum formatiert als:');

define('TEXT_SHOW_STATUS', 'Status');

define('TEXT_DELETE_IMAGE', 'Bild(er) l&ouml;schen?');
define('TEXT_DELETE_IMAGE_INTRO', 'ACHTUNG: Durch das L�schen werden diese(s) Bild(er) komplett entfernt. Dies f�hrt zu Problemen, wenn Sie diese Bilder noch woanders in Verwendung haben!');

define('TEXT_FAQDESK_STICKY', 'Sticky Status');
define('TEXT_FAQDESK_STICKY_ON', 'EIN');
define('TEXT_FAQDESK_STICKY_OFF', 'AUS');
define('TABLE_HEADING_STICKY', 'Sticky');

define('TEXT_FAQDESK_IMAGE', 'FAQ Bild(er):');

define('TEXT_FAQDESK_IMAGE_ONE', 'Erstes Bild:');
define('TEXT_FAQDESK_IMAGE_TWO', 'Zweites Bild:');
define('TEXT_FAQDESK_IMAGE_THREE', 'Drittes Bild:');

define('TEXT_FAQDESK_IMAGE_SUBTITLE', 'Bildtitel f&uuml;r Erstes Bild:');
define('TEXT_FAQDESK_IMAGE_SUBTITLE_TWO', 'Bildtitel f&uuml;r Zweites Bild:');
define('TEXT_FAQDESK_IMAGE_SUBTITLE_THREE', 'Bildtitel f&uuml;r Drittes Bild:');

define('TEXT_FAQDESK_IMAGE_PREVIEW_ONE', 'FAQ Image Nummer 1:');
define('TEXT_FAQDESK_IMAGE_PREVIEW_TWO', 'FAQ Image Nummer 2:');
define('TEXT_FAQDESK_IMAGE_PREVIEW_THREE', 'FAQ Image Nummer 3:');

/*

	osCommerce, Open Source E-Commerce Solutions ---- http://www.oscommerce.com
	Copyright (c) 2002 osCommerce
	Released under the GNU General Public License

	IMPORTANT NOTE:

	This script is not part of the official osC distribution but an add-on contributed to the osC community.
	Please read the NOTE and INSTALL documents that are provided with this file for further information and installation notes.

	script name:	FaqDesk
	version:		1.2.5
	date:			2003-09-01
	author:			Carsten aka moyashi
	web site:		www..com

*/
?>