<?php
/*
  $Id: create_account.php,v 1.2 2004/03/05 00:36:42 ccwjr Exp $

  The Exchange Project - Community Made Shopping!
  http://www.theexchangeproject.org

  Copyright (c) 2000,2001 The Exchange Project

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Konto er&ouml;ffnen');
define('HEADING_TITLE', 'Neukunden anlegen');
define('HEADING_NEW', 'Bestellablauf');
define('TEXT_ORIGIN_LOGIN', '<font color="#FF0000"><small><b>HINWEIS:</b></font></small> Wenn Sie bereits ein Konto bei uns haben, melden Sie sich bitte bei der <a href="%s"><u>Anmeldeseite</u></a> an.');
define('TEXT_VISITOR_CART', '<font color="#FF0000"><b> um Ihre Bestellung so rasch als m�glich bearbeiten zu k�nnen, ben�tigen wir noch folgende Informationen.</b></font>');
define('TEXT_RETURN_CUSTOMER', '<font color="#FF0000">Sie haben bereits ein Profil? Bitte meledn Sie sich an!</font>');
define('NAVBAR_NEW_TITLE', 'Bestellablauf');
define('TEXT_PRIVACY', '<font color="#FF0000"><b>Sie haben bei uns noch nicht gekauft? Das Bestellen ist einfach. Bitte f�llen Sie alle notwendigen Felder aus, und klicken Sie dann den \'Weiter\' Button. </b>');

?>