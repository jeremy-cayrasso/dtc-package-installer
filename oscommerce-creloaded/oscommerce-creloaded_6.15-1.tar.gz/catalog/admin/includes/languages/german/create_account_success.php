<?php
/*
  $Id: create_account_success.php,v 1.2 2004/03/05 00:36:42 ccwjr Exp $

  The Exchange Project - Community Made Shopping!
  http://www.theexchangeproject.org

  Copyright (c) 2000,2001 The Exchange Project

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Konto Erstellen');
define('NAVBAR_TITLE_2', 'Erfolg');
define('HEADING_TITLE', 'Kundenkonto wurde erstellt!');
define('TEXT_ACCOUNT_CREATED', 'Gl&uuml;ckwunsch! Das neue Konto wurde erfolgreich er&ouml;ffnet! Sie k&ouml;nnen nun eine <a href="' . "create_order.php" . '"> Manuelle Bestellung</a> durchf&uuml;hren. <p><p>

Oder klicken Sie den Zur&uuml;ck-Button um zur Admin-Indexseite zur&uuml;ckzukehren....');
?>