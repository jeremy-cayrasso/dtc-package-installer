<?php
/*
  $Id: stats_monthly_sales.php,v 1.3 2004/03/15 12:13:02 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Monatlicher Verkaufs- und MwSt.-Report');
define('HEADING_TITLE_STATUS','Status');
define('HEADING_TITLE_REPORTED','Berichtet');
define('TEXT_ALL_ORDERS', 'Alle Bestellungen');
define('TEXT_NOTHING_FOUND', 'Kein Eingang zu dieser Datum/Status-Auswahl gefunden');
define('TEXT_BUTTON_REPORT_PRINT','Drucken');
define('TEXT_BUTTON_REPORT_FILE','Datei');
define('TEXT_BUTTON_REPORT_HELP','Hilfe');
define('TEXT_BUTTON_REPORT_PRINT_DESC', 'Report in in einem Drucker-freundlichem Fenster zeigen');
define('TEXT_BUTTON_REPORT_FILE_DESC', 'Download einer Textdatei mit den Daten dieses Reports, als CSV(Comma Separated Values)');
define('TEXT_BUTTON_REPORT_HELP_DESC', '&Uuml;ber diesen Report und wie man dessen Features nutzt');
define('TEXT_REPORT_DATE_FORMAT', 'j M Y -   g:i a'); // date format string
//  as specified in php manual here: http://www.php.net/manual/en/function.date.php
define('TABLE_HEADING_YEAR','Jahr');
define('TABLE_HEADING_MONTH', 'Monat');
define('TABLE_HEADING_DAYS', 'Tage');
define('TABLE_HEADING_INCOME', 'Brutto<br> Einnahmen');
define('TABLE_HEADING_SALES', 'Produkt<br> Umsatz');
define('TABLE_HEADING_NONTAXED', 'steuerfreier<br> Umsatz');
define('TABLE_HEADING_TAXED', 'zu versteuernder<br> Umsatz');
define('TABLE_HEADING_TAX_COLL', 'MwSt.<br> bezahlt');
define('TABLE_HEADING_SHIPHNDL', 'Lieferkosten<br> & Handling');
define('TABLE_HEADING_LOWORDER', 'Mindestmengen-<br> Zuschl&auml;ge');
define('TABLE_HEADING_OTHER', 'Geschenk<br> Gutscheine');  // could be any other extra class value
define('TABLE_FOOTER_YTD','JGD');
define('TABLE_FOOTER_YEAR','JAHR');
?>