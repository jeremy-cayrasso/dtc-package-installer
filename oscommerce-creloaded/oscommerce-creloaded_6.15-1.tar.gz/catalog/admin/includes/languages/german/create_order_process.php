<?php
/*
  $Id: create_order_process.php,v 1.3 2004/03/15 12:13:02 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_CREATE', 'Kundendetails &uuml;berpr&uuml;fen');
?>