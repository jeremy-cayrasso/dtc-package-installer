<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Zugang verboten');
define('NAVBAR_TITLE', 'Keine geigneten Zugangsrechte');
define('TEXT_MAIN', '&nbsp;Bitte kontaktieren Sie den <b>Webmaster</b> um mehr Zugang <br>&nbsp;zu beantragen oder wenn Sie auf ein Problem gestossen sind.<br>&nbsp;');
define('TEXT_BACK', 'Zur&uuml;ck');
?>
