<?php
/*
  $Id: create_account_success.php,v 1.2 2004/03/05 00:36:41 ccwjr Exp $

  The Exchange Project - Community Made Shopping!
  http://www.theexchangeproject.org

  Copyright (c) 2000,2001 The Exchange Project

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Create an Account');
define('NAVBAR_TITLE_2', 'Success');
define('HEADING_TITLE', 'Customer\'s Account Has Been Created!');
define('TEXT_ACCOUNT_CREATED', 'Congratulations! The new account has been successfully created! You can now take a <a href="' . "create_order.php" . '"> manual order</a>. <p><p>

Or click the BACK button to go to the Admin Index Page....');
?>
