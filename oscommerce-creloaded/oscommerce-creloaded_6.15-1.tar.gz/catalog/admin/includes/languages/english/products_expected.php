<?php
/*
  $Id: products_expected.php,v 1.2 2004/03/05 00:36:41 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Products Expected');

define('TABLE_HEADING_PRODUCTS', 'Products');
define('TABLE_HEADING_DATE_EXPECTED', 'Date Expected');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_INFO_DATE_EXPECTED', 'Date Expected:');
?>
