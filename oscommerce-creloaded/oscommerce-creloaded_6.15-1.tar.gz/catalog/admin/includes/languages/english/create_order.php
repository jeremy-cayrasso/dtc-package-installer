<?php
/*
  $Id: create_order.php,v 1.3 2004/09/08 00:36:41 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2004 osCommerce

  Released under the GNU General Public License

*/
define('HEADING_STEP1', 'STEP 1 - Choose a customer & check their details');

define('HEADING_CREATE', 'Check Customer Details');

define('TEXT_SELECT_CUST', 'Select a Customer:');
define('BUTTON_TEXT_SELECT_CUST', 'Select This Customer');
define('TEXT_OR_BY', 'or Customer ID:');
define('BUTTON_TEXT_CHOOSE_CUST', 'Select This Customer ID');

?>
