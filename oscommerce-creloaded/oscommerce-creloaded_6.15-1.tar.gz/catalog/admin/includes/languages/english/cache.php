<?php
/*
  $Id: cache.php,v 1.2 2004/03/05 00:36:41 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Cache Control');

define('TABLE_HEADING_CACHE', 'Cache Blocks');
define('TABLE_HEADING_DATE_CREATED', 'Date Created');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_FILE_DOES_NOT_EXIST', 'File does not exist');
define('TEXT_CACHE_DIRECTORY', 'Cache Directory:');

define('ERROR_CACHE_DIRECTORY_DOES_NOT_EXIST', 'Error: Cache directory does not exist. Please set this Configuration->Cache.');
define('ERROR_CACHE_DIRECTORY_NOT_WRITEABLE', 'Error: Cache directory is not writeable.');

// labels for Tools>Cache Control
define('TEXT_CACHE_CATEGORIES', 'Categories Box');
define('TEXT_CACHE_CATEGORIES1', 'Categories Box 1');
define('TEXT_CACHE_CATEGORIES2', 'Categories Box 2');
define('TEXT_CACHE_CATEGORIES3', 'Categories Box 3');
define('TEXT_CACHE_CATEGORIES4', 'Categories Box 4');
define('TEXT_CACHE_CATEGORIES5', 'Categories Box 5');
define('TEXT_CACHE_ALLPROD', 'All Produces');
define('TEXT_CACHE_ALLMANUF', 'All Manufactures');
define('TEXT_CACHE_ALLCATS', 'All Categories');
define('TEXT_CACHE_MANUFACTURERS', 'Manufacturers Box');
define('TEXT_CACHE_ALSO_PURCHASED', 'Also Purchased Module');
define('TEXT_CACHE_COOLMENU', 'Cool Menu');


?>
