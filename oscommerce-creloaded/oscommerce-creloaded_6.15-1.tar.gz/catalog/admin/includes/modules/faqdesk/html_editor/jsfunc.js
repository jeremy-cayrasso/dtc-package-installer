function storeCaret(text) {
	if (text.createTextRange) {
		text.caretPos = document.selection.createRange().duplicate();
	}
}


function setsmiley_1_s(text) {
	if (document.new_product.faqdesk_answer_short_1.createTextRange && document.new_product.faqdesk_answer_short_1.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_short_1.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_short_1.value += text;
	document.new_product.faqdesk_answer_short_1.focus(caretPos)
}

function setsmiley_2_s(text) {
	if (document.new_product.faqdesk_answer_short_2.createTextRange && document.new_product.faqdesk_answer_short_2.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_short_2.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_short_2.value += text;
	document.new_product.faqdesk_answer_short_2.focus(caretPos)
}

function setsmiley_3_s(text) {
	if (document.new_product.faqdesk_answer_short_3.createTextRange && document.new_product.faqdesk_answer_short_3.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_short_3.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_short_3.value += text;
	document.new_product.faqdesk_answer_short_3.focus(caretPos)
}

function setsmiley_4_s(text) {
	if (document.new_product.faqdesk_answer_short_4.createTextRange && document.new_product.faqdesk_answer_short_4.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_short_4.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_short_4.value += text;
	document.new_product.faqdesk_answer_short_4.focus(caretPos)
}

function setsmiley_5_s(text) {
	if (document.new_product.faqdesk_answer_short_5.createTextRange && document.new_product.faqdesk_answer_short_5.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_short_5.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_short_5.value += text;
	document.new_product.faqdesk_answer_short_5.focus(caretPos)
}

function setsmiley_6_s(text) {
	if (document.new_product.faqdesk_answer_short_6.createTextRange && document.new_product.faqdesk_answer_short_6.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_short_6.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_short_6.value += text;
	document.new_product.faqdesk_answer_short_6.focus(caretPos)
}

function setsmiley_7_s(text) {
	if (document.new_product.faqdesk_answer_short_7.createTextRange && document.new_product.faqdesk_answer_short_7.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_short_7.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_short_7.value += text;
	document.new_product.faqdesk_answer_short_7.focus(caretPos)
}

function setsmiley_8_s(text) {
	if (document.new_product.faqdesk_answer_short_8.createTextRange && document.new_product.faqdesk_answer_short_8.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_short_8.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_short_8.value += text;
	document.new_product.faqdesk_answer_short_8.focus(caretPos)
}

function setsmiley_9_s(text) {
	if (document.new_product.faqdesk_answer_short_9.createTextRange && document.new_product.faqdesk_answer_short_9.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_short_9.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_short_9.value += text;
	document.new_product.faqdesk_answer_short_9.focus(caretPos)
}


function setsmiley_1_c(text) {
	if (document.new_product.faqdesk_answer_long_1.createTextRange && document.new_product.faqdesk_answer_long_1.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_long_1.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_long_1.value += text;
	document.new_product.faqdesk_answer_long_1.focus(caretPos)
}

function setsmiley_2_c(text) {
	if (document.new_product.faqdesk_answer_long_2.createTextRange && document.new_product.faqdesk_answer_long_2.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_long_2.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_long_2.value += text;
	document.new_product.faqdesk_answer_long_2.focus(caretPos)
}

function setsmiley_3_c(text) {
	if (document.new_product.faqdesk_answer_long_3.createTextRange && document.new_product.faqdesk_answer_long_3.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_long_3.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_long_3.value += text;
	document.new_product.faqdesk_answer_long_3.focus(caretPos)
}

function setsmiley_4_c(text) {
	if (document.new_product.faqdesk_answer_long_4.createTextRange && document.new_product.faqdesk_answer_long_4.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_long_4.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_long_4.value += text;
	document.new_product.faqdesk_answer_long_4.focus(caretPos)
}

function setsmiley_5_c(text) {
	if (document.new_product.faqdesk_answer_long_5.createTextRange && document.new_product.faqdesk_answer_long_5.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_long_5.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_long_5.value += text;
	document.new_product.faqdesk_answer_long_5.focus(caretPos)
}

function setsmiley_6_c(text) {
	if (document.new_product.faqdesk_answer_long_6.createTextRange && document.new_product.faqdesk_answer_long_6.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_long_6.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_long_6.value += text;
	document.new_product.faqdesk_answer_long_6.focus(caretPos)
}

function setsmiley_7_c(text) {
	if (document.new_product.faqdesk_answer_long_7.createTextRange && document.new_product.faqdesk_answer_long_7.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_long_7.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_long_7.value += text;
	document.new_product.faqdesk_answer_long_7.focus(caretPos)
}

function setsmiley_8_c(text) {
	if (document.new_product.faqdesk_answer_long_8.createTextRange && document.new_product.faqdesk_answer_long_8.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_long_8.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_long_8.value += text;
	document.new_product.faqdesk_answer_long_8.focus(caretPos)
}

function setsmiley_9_c(text) {
	if (document.new_product.faqdesk_answer_long_9.createTextRange && document.new_product.faqdesk_answer_long_9.caretPos) {
		var caretPos = document.new_product.faqdesk_answer_long_9.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.faqdesk_answer_long_9.value += text;
	document.new_product.faqdesk_answer_long_9.focus(caretPos)
}

function orignal_code_copyright(text) {
//orginally code and images are from  htttp://www.fusionphp.com
}
