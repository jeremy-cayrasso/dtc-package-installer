function storeCaret(text) {
	if (text.createTextRange) {
		text.caretPos = document.selection.createRange().duplicate();
	}
}


function setsmiley_1_s(text) {
	if (document.new_product.newsdesk_article_shorttext_1.createTextRange && document.new_product.newsdesk_article_shorttext_1.caretPos) {
		var caretPos = document.new_product.newsdesk_article_shorttext_1.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_shorttext_1.value += text;
	document.new_product.newsdesk_article_shorttext_1.focus(caretPos)
}

function setsmiley_2_s(text) {
	if (document.new_product.newsdesk_article_shorttext_2.createTextRange && document.new_product.newsdesk_article_shorttext_2.caretPos) {
		var caretPos = document.new_product.newsdesk_article_shorttext_2.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_shorttext_2.value += text;
	document.new_product.newsdesk_article_shorttext_2.focus(caretPos)
}

function setsmiley_3_s(text) {
	if (document.new_product.newsdesk_article_shorttext_3.createTextRange && document.new_product.newsdesk_article_shorttext_3.caretPos) {
		var caretPos = document.new_product.newsdesk_article_shorttext_3.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_shorttext_3.value += text;
	document.new_product.newsdesk_article_shorttext_3.focus(caretPos)
}

function setsmiley_4_s(text) {
	if (document.new_product.newsdesk_article_shorttext_4.createTextRange && document.new_product.newsdesk_article_shorttext_4.caretPos) {
		var caretPos = document.new_product.newsdesk_article_shorttext_4.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_shorttext_4.value += text;
	document.new_product.newsdesk_article_shorttext_4.focus(caretPos)
}

function setsmiley_5_s(text) {
	if (document.new_product.newsdesk_article_shorttext_5.createTextRange && document.new_product.newsdesk_article_shorttext_5.caretPos) {
		var caretPos = document.new_product.newsdesk_article_shorttext_5.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_shorttext_5.value += text;
	document.new_product.newsdesk_article_shorttext_5.focus(caretPos)
}

function setsmiley_6_s(text) {
	if (document.new_product.newsdesk_article_shorttext_6.createTextRange && document.new_product.newsdesk_article_shorttext_6.caretPos) {
		var caretPos = document.new_product.newsdesk_article_shorttext_6.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_shorttext_6.value += text;
	document.new_product.newsdesk_article_shorttext_6.focus(caretPos)
}

function setsmiley_7_s(text) {
	if (document.new_product.newsdesk_article_shorttext_7.createTextRange && document.new_product.newsdesk_article_shorttext_7.caretPos) {
		var caretPos = document.new_product.newsdesk_article_shorttext_7.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_shorttext_7.value += text;
	document.new_product.newsdesk_article_shorttext_7.focus(caretPos)
}

function setsmiley_8_s(text) {
	if (document.new_product.newsdesk_article_shorttext_8.createTextRange && document.new_product.newsdesk_article_shorttext_8.caretPos) {
		var caretPos = document.new_product.newsdesk_article_shorttext_8.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_shorttext_8.value += text;
	document.new_product.newsdesk_article_shorttext_8.focus(caretPos)
}

function setsmiley_9_s(text) {
	if (document.new_product.newsdesk_article_shorttext_9.createTextRange && document.new_product.newsdesk_article_shorttext_9.caretPos) {
		var caretPos = document.new_product.newsdesk_article_shorttext_9.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_shorttext_9.value += text;
	document.new_product.newsdesk_article_shorttext_9.focus(caretPos)
}


function setsmiley_1_c(text) {
	if (document.new_product.newsdesk_article_description_1.createTextRange && document.new_product.newsdesk_article_description_1.caretPos) {
		var caretPos = document.new_product.newsdesk_article_description_1.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_description_1.value += text;
	document.new_product.newsdesk_article_description_1.focus(caretPos)
}

function setsmiley_2_c(text) {
	if (document.new_product.newsdesk_article_description_2.createTextRange && document.new_product.newsdesk_article_description_2.caretPos) {
		var caretPos = document.new_product.newsdesk_article_description_2.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_description_2.value += text;
	document.new_product.newsdesk_article_description_2.focus(caretPos)
}

function setsmiley_3_c(text) {
	if (document.new_product.newsdesk_article_description_3.createTextRange && document.new_product.newsdesk_article_description_3.caretPos) {
		var caretPos = document.new_product.newsdesk_article_description_3.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_description_3.value += text;
	document.new_product.newsdesk_article_description_3.focus(caretPos)
}

function setsmiley_4_c(text) {
	if (document.new_product.newsdesk_article_description_4.createTextRange && document.new_product.newsdesk_article_description_4.caretPos) {
		var caretPos = document.new_product.newsdesk_article_description_4.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_description_4.value += text;
	document.new_product.newsdesk_article_description_4.focus(caretPos)
}

function setsmiley_5_c(text) {
	if (document.new_product.newsdesk_article_description_5.createTextRange && document.new_product.newsdesk_article_description_5.caretPos) {
		var caretPos = document.new_product.newsdesk_article_description_5.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_description_5.value += text;
	document.new_product.newsdesk_article_description_5.focus(caretPos)
}

function setsmiley_6_c(text) {
	if (document.new_product.newsdesk_article_description_6.createTextRange && document.new_product.newsdesk_article_description_6.caretPos) {
		var caretPos = document.new_product.newsdesk_article_description_6.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_description_6.value += text;
	document.new_product.newsdesk_article_description_6.focus(caretPos)
}

function setsmiley_7_c(text) {
	if (document.new_product.newsdesk_article_description_7.createTextRange && document.new_product.newsdesk_article_description_7.caretPos) {
		var caretPos = document.new_product.newsdesk_article_description_7.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_description_7.value += text;
	document.new_product.newsdesk_article_description_7.focus(caretPos)
}

function setsmiley_8_c(text) {
	if (document.new_product.newsdesk_article_description_8.createTextRange && document.new_product.newsdesk_article_description_8.caretPos) {
		var caretPos = document.new_product.newsdesk_article_description_8.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_description_8.value += text;
	document.new_product.newsdesk_article_description_8.focus(caretPos)
}

function setsmiley_9_c(text) {
	if (document.new_product.newsdesk_article_description_9.createTextRange && document.new_product.newsdesk_article_description_9.caretPos) {
		var caretPos = document.new_product.newsdesk_article_description_9.caretPos;
		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
		text + ' ' : text;
	}
	else document.new_product.newsdesk_article_description_9.value += text;
	document.new_product.newsdesk_article_description_9.focus(caretPos)
}

// this code has been added by wolfen and replaces the original code below
 function orignal_code_copyright(text) { 

// orginally code and images are from htttp://www.fusionphp.com 

 }
/*
// the new code starts here by wolfen
function submitonce(theform) { 
// if IE 4+ or NS 6+ 
if (document.all || document.getElementById) { 
// hunt down "submit" and "reset" 
for (i=0;i<theform.length;i++) { 
var tempobj=theform.elements[i]; 
if(tempobj.type.toLowerCase()=="submit"||tempobj.type.toLowerCase()=="reset") { 
//disable it 
tempobj.disabled=true; 
} 
} 
} 
} 

function check_if_selected() { 
var nonactive=true; 
// if IE 4+ or NS 6+ 
if (document.all || document.getElementById) { 
// hunt down "checkbox" 
for (i=0;i<deleteform.length;i++) { 
var tempobj=deleteform.elements[i]; 
if(tempobj.type.toLowerCase()=="checkbox") { 
//disable it 
if (document.forms[ "deleteform" ].elements[tempobj.name].checked) 
nonactive=false; 
} 
} 
} 
} 
function orignal_code_copyright(text) { 

//orginally code and images are from htttp://www.fusionphp.com 
//       date:       			06-05-2004 (dd/mm/yyyy)
//	modified code by:		Wolfen aka 241

} */
