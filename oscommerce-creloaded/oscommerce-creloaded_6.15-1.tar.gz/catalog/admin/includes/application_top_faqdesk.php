<?
// Begin faqdesk
define('FILENAME_FAQDESK', 'faqdesk.php');
define('FILENAME_FAQDESK_CONFIGURATION', 'faqdesk_configuration.php');
define('FILENAME_FAQDESK_REVIEWS', 'faqdesk_reviews.php');

define('EDITOR_IMAGE', DIR_WS_INCLUDES . 'modules/faqdesk/html_editor/editor_images');
// End faqdesk


// Begin faqdesk
define('TABLE_FAQDESK', 'faqdesk');
define('TABLE_FAQDESK_DESCRIPTION', 'faqdesk_description');
define('TABLE_FAQDESK_TO_CATEGORIES', 'faqdesk_to_categories');
define('TABLE_FAQDESK_CATEGORIES', 'faqdesk_categories');
define('TABLE_FAQDESK_CATEGORIES_DESCRIPTION', 'faqdesk_categories_description');
define('TABLE_FAQDESK_CONFIGURATION', 'faqdesk_configuration');
define('TABLE_FAQDESK_CONFIGURATION_GROUP', 'faqdesk_configuration_group');
define('TABLE_FAQDESK_REVIEWS', 'faqdesk_reviews');
define('TABLE_FAQDESK_REVIEWS_DESCRIPTION', 'faqdesk_reviews_description');
// End faqdesk





/*

	osCommerce, Open Source E-Commerce Solutions ---- http://www.oscommerce.com
	Copyright (c) 2002 osCommerce
	Released under the GNU General Public License

	IMPORTANT NOTE:

	This script is not part of the official osC distribution but an add-on contributed to the osC community.
	Please read the NOTE and INSTALL documents that are provided with this file for further information and installation notes.

	script name:	FaqDesk
	version:		1.2.5
	date:			2003-09-01
	author:			Carsten aka moyashi
	web site:		www..com

*/
?>
