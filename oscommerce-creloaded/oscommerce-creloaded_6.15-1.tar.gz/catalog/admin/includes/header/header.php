<style>
body {
	margin: 0px;
	padding: 0px;
	color : #333;
	background-color : #FFF;
	font-size : 11px;
	font-family : Arial, Helvetica, sans-serif;
}
#wrapper {
        border: 0px;
        margin: 0px;
        margin-left: auto;
        margin-right: auto;
        padding: 0px;
}
#header {
        background-color: #FFF;
        background-position: right top;
        border-bottom: 4px solid #80B5D7;
}
#creHead {
        position: relative;
        width: 100%;
        background: url(header/bg.gif);
        margin: 0px;
        padding: 0px;
}
#break {
	height: 50px;
}
form {
    margin: 0px;
}
.button {
	border : solid 1px #cccccc;
	background: #E9ECEF;
	color : #666666;
	font-weight : bold;
	font-size : 11px;
	padding: 4px;
}
.login {
	margin-left: auto;
	margin-right: auto;
	margin-top: 6em;
	padding: 15px;
	border: 1px solid #cccccc;
	width: 429px;
	background: #F1F3F5;
}
.login h1 {
	background-position: left top;
	color: #333;
	margin: 0px;
	height: 50px;
	padding: 15px 4px 0 50px;
 	text-align: left;
	font-size: 1.5em;
}
.login p {
	padding: 0 1em 0 1em;
	}
.form-block {
	border: 1px solid #cccccc;
	background: #E9ECEF;
	padding-top: 15px;
	padding-left: 10px;
	padding-bottom: 10px;
	padding-right: 10px;
}
.login-form {
	text-align: left;
	float: right;
	width: 60%;
}
.login-text {
	text-align: left;
	width: 40%;
	float: left;
}
.inputlabel {
	font-weight: bold;
	text-align: left;
	}
.inputbox {
	width: 150px;
	margin: 0 0 1em 0;
	border: 1px solid #cccccc;
	}
.clr {
    clear:both;
    }
.ctr {
	text-align: center;
}
a.bdLink:link, a.bdLink:visited {
	color: #000000;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
}
a.bdLink:hover {
	color: #000000;
	text-decoration:underline;
}
</style>
<div id="wrapper">
    <div id="header">
           <div id="creHead">
             <table width="100%"  border="0" cellspacing="0" cellpadding="0">
               <tr>
                 <td><img src="header/admin_logo.gif" alt="" /></td>
                 <td align="right" valign="bottom"><?php echo '<a href="' . tep_href_link(FILENAME_DEFAULT, '', 'NONSSL') . '" class="bdLink">' . HEADER_TITLE_ADMINISTRATION . '</a>';?>&nbsp;&nbsp;&nbsp; <?php echo '<a target=_blank href="' . tep_catalog_href_link() . '" class="bdLink" "target=_blank">';?>Catalog</a>
&nbsp;&nbsp;&nbsp; <?php echo '<a target=_blank href="http://www.creloaded.com" class="bdLink" "target=_blank">';?>Support Desk</a> &nbsp;&nbsp;&nbsp;<?php echo '<a href="' . tep_href_link(FILENAME_LOGOFF, '', 'NONSSL') . '" class="bdLink">' . HEADER_TITLE_LOGOFF . '</a>';?>&nbsp;&nbsp;&nbsp;&nbsp;</td>
               </tr>
             </table>
           </div>
    </div>
</div>