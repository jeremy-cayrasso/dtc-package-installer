<?php
  /*
  WebMakers.com Added: Java Scripts
  */
?>
<?php /* BOF: WebMakers.com Added: PopUp Window */ ?>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function NewWindow(mypage, myname, w, h, scroll) {
var winl = (screen.width - w) / 2;
var wint = (screen.height - h) / 2;
winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable'
win = window.open(mypage, myname, winprops)
if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}
//  End -->
</script>
<?php /* EOF: WebMakers.com Added: PopUp Window */ ?>
<?php /* BOF: WebMakers.com Added: PopUp Window */ ?>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function NewWindow2(mypage, myname, w, h, scroll) {
var winl = (screen.width - w) / 2;
var wint = (screen.height - h) / 2;
winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable'
win = window.open(mypage, myname, winprops)
if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}
//  End -->
</script>
<?php /* EOF: WebMakers.com Added: PopUp Window */ ?>
