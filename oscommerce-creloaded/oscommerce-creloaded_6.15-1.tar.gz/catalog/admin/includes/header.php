<?php
/*
  $Id: header.php,v 1.1.1.1 2004/03/04 23:39:42 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/


?>

<table border="0" width="100%" height="82" cellspacing="0" cellpadding="0" background="images/logo-banner_bg.gif">
  <tr>
    <td background="images/logo-banner_bg.gif"><a href="http://www.chainreactionweb.com">
    <img src="images/admin_logo.gif" border="0" width="211" height="82"></a>
    </td>
    <td>&nbsp;</td>
<td background="images/admin_logo_right.gif" width="462" height="82">
<table border="0" width="100%" height="72" cellspacing="0" cellpadding="0">
  <tr>
    <td class="headerBarContent" align="center">

<font COLOR="#333333" SIZE="1"><strong>If you would like professional hosting and real support<br> for this application
    please go to:<br>
    <a href="http://www.chainreactionweb.com" class="headerLink">www.chainreactionweb.com</a>
    </strong></font>
    </td>
    </tr>
  <tr>
    <td class="headerBarContent" align="center">&nbsp;
    <a href="http://www.creloaded.com/" target="_blank" class="headerLink">
    Help Desk</a>&nbsp; |&nbsp;
    <a href="http://www.chainreactionweb.com/" class="headerLink">Chainreactionweb</a>&nbsp;
    |&nbsp; <a href="http://www.oscommerce.com" class="headerLink">osCommerce</a>&nbsp;
    |&nbsp; <?php echo '<a href="' . tep_catalog_href_link() . '" class="headerLink">';?>Catalog</a>&nbsp;
    |&nbsp; <?php echo '<a href="' . tep_href_link(FILENAME_DEFAULT, '', 'NONSSL') . '" class="headerLink">' . HEADER_TITLE_ADMINISTRATION . '</a>';?>&nbsp;
    |&nbsp; <?php echo '<a href="' . tep_href_link(FILENAME_LOGOFF, '', 'NONSSL') . '" class="headerLink">' . HEADER_TITLE_LOGOFF . '</a>';?>&nbsp;
    </td>
  </tr>
</table>
</td>
    </tr>
</table>
<script language="javascript" src="includes/menu.js"></script>
<?php if (MENU_DHTML == 'True') require(DIR_WS_INCLUDES . 'header_navigation.php'); 

  if ($messageStack->size > 0) {
    echo $messageStack->output();
  }
?>
