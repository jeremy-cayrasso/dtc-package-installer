<?php

// ACCESSIBILITE
// la page /oo offre une lecture en mode "texte seul"
// des 3 articles les plus recents...

@header("Location: ../spip.php?page=sommaire_texte");

?>
