<?php

// ACCESSIBILITE
// la page /oo offre une lecture en mode "texte seul"
// des 3 articles les plus recents...

@header("Location: ../?set_disp=4&set_options=basiques");

?>
