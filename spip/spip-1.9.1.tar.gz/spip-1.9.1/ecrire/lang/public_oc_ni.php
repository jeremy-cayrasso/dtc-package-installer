<?php

// This is a SPIP language file  --  Ceci est un fichier langue de SPIP

$GLOBALS[$GLOBALS['idx_lang']] = array(


// A
'accueil_site' => 'Acu&egrave;lh dau sit',
'articles' => 'Articles',
'articles_auteur' => 'Articles d\'aquel autor',
'articles_populaires' => 'Lu articles mai populars',
'articles_recents' => 'Lu articles mai recents',
'articles_rubrique' => 'Articles d\'aquela rubrica',
'aucun_article' => 'L\'i a minga d\'article a aquela adre&ccedil;a ',
'aucun_auteur' => 'L\'i a minga d\'autor a aquela adre&ccedil;a ',
'aucun_site' => 'L\'i a minga de sit a aquela adre&ccedil;a ',
'aucune_breve' => 'L\'i a minga de br&egrave;va a aquela adre&ccedil;a ',
'aucune_rubrique' => 'L\'i a minga de rubrica a aquela adre&ccedil;a ',
'autres_breves' => 'Autri br&egrave;vas',
'autres_groupes_mots_clefs' => 'Autres grops de m&ograve;ts claus',
'autres_sites' => 'Autres sits',


// B
'bonjour' => 'B&ograve;njorn',
'breves' => 'Br&egrave;vas',


// C
'commenter_site' => 'Comentar aqueu sit',


// D
'date' => 'Data',
'dernier_ajout' => 'Darri&egrave;r ajust',
'dernieres_breves' => 'Darri&egrave;ras br&egrave;vas',
'derniers_articles' => 'Darri&egrave;rs articles',
'derniers_commentaires' => 'Darri&egrave;rs comentaris',
'derniers_messages_forum' => 'Darri&egrave;rs messatges publicats dins lu forums',


// E
'edition_mode_texte' => 'Edicion en m&ograve;de t&egrave;xt de',
'en_reponse' => 'En responsa a:',
'en_resume' => 'En resumit',
'envoyer_message' => 'Mandar un messatge',
'espace_prive' => 'Espaci privat',


// F
'forum' => 'Forum',


// H
'hierarchie_site' => 'Ierarquia dau sit',


// J
'jours' => 'jorns',


// M
'meme_auteur' => 'Dau meme autor',
'meme_rubrique' => 'Dins la mema rubrica',
'memes_auteurs' => 'Dei memes autors',
'message' => 'Messatge',
'messages_forum' => 'Messatges de forum',
'messages_recents' => 'Lu messatges de forums mai recents',
'mots_clefs' => 'M&ograve;ts claus',
'mots_clefs_meme_groupe' => 'M&ograve;ts claus dins lo meme grop',


// N
'navigation' => 'Navigacion',
'nom' => 'Nom',
'nouveautes' => 'Li nov&egrave;utats',
'nouveautes_web' => 'Nov&egrave;utats sobre lo web',
'nouveaux_articles' => 'Articles n&ograve;us',
'nouvelles_breves' => 'Br&egrave;vas nov&egrave;las',


// P
'page_precedente' => 'p&agrave;gina anteriora',
'page_suivante' => 'p&agrave;gina seguenta',
'par_auteur' => 'per',
'participer_site' => 'Pod&egrave;tz participar a la vida d\'aqueu sit e prepauar lu voastres articles en vos inscriure &ccedil;ai sota. Receberetz un e-mail que vos indicar&agrave; lu voastres c&ograve;des per accedir a l\'espaci privat dau sit.',
'plan_site' => 'Plan dau sit',
'popularite' => 'Popularitat',
'poster_message' => 'Postar un messatge',
'proposer_site' => 'Pod&egrave;tz prepauar un site a ajustar dins aquela rubrica&nbsp;:',


// R
'repondre_article' => 'Respondre a aquel article',
'repondre_breve' => 'Respondre a aquela br&egrave;va',
'repondre_message' => 'Respondre a aqueu messatge',
'resultats_recherche' => 'Resultats de la rec&egrave;rca',
'retour_debut_forums' => 'Retorn au comen&ccedil;ament dei forums',
'rubrique' => 'Rubrica',
'rubriques' => 'Rubricas',


// S
'signatures_petition' => 'Signaturas',
'site_realise_avec_spip' => 'Sit realisat emb SPIP',
'sites_web' => 'Sits web',
'sous_rubriques' => 'Sosrubricas',
'suite' => 'seguida',
'sur_web' => 'Sobre lo web',
'syndiquer_rubrique' => 'Sindicar aquela rubrica',
'syndiquer_site' => 'Sindicar tot lo sit',


// T
'texte_lettre_information' => 'Vequ&iacute; la letra d\'informacion dau sit',
'texte_lettre_information_2' => 'Aquela letra recensa lu articles e br&egrave;vas publicats desp&iacute;',


// V
'ver_imprimer' => 'Version d\'estampar',
'voir_en_ligne' => 'Vejatz en linha'

);


?>
