This directory (/tmp) is used for saving various temporary files, including "template" html files from the templates.php script, uploaded files when importing tokens, surveys, groups or questions, and image files from jpgraph and the statistics script.


Set this directory to 777 (world read/write) - or some level where your server process has read AND write access. 