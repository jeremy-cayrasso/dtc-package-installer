<?php
/*
* Installer for the PHPSurveyor
*
*
*/

/*
if(file_exists('config.php'))
{
die("PHPSurveyor is allready installed") ;
}
*/




function check_connection($dbname,$dbusername,$dbpassword)
{

}
function checkGettext()
{

}

function writeConfiguration($configuration_array)
{

}
?>
