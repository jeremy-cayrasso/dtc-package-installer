"Basic" Template for phpSurveyor

--------------------------------
Modified 7/18/06 - swales
- Copy of Basic template
- Demonstrates how to show Last Modified on navigator.pstpl page.


Developed by Tor de Vries for Zoemail.


Get my email address at http://www.zoemail.net/?tor



This is freeware.  Modify at your own will (and risk).

To use your own logo, just replace the logo.gif file.
Its dimensions are 211 x 72 pixels.

I eliminated the group name and descriptions, because in
our use of phpSurveyor, we only used groups to break the
survey into pages for ease of use... not actually for 
"groups" as the visitor might define them.