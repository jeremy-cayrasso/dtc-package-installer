This template is based on the Eirenicon template by Mark F. Rabideau.

Hi!

To customize this template you just need to make a few changes:

1. Colour code: Browse all files and replace the colour code "#17479E" with your colour code. Don't forget to change the colour of the "chart.jpg" file into your colour.

2. Replace the existing "logo.jpg" file with your new logo.jpg file. The size of the logo will not automatically be adjusted to fit into the survey so just use the existing logo file as a template. In case you want to use another format just replace the .jpg ending in the "survey.pstpl" file with the new format ending (.gif, .png etc.)

That's it. Done.

Have fun!

Andreas