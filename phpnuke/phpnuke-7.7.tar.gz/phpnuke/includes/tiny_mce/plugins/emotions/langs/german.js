// DE lang variables


tinyMCELang['lang_insert_emotions_title'] = 'Emotion einf&uuml;gen';
tinyMCELang['lang_emotions_desc'] = 'Emotion';

