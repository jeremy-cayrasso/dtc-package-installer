// SE lang variables

tinyMCELang['lang_insert_image_alt2'] = 'Bildentitel';
tinyMCELang['lang_insert_image_onmousemove'] = 'Alternativ bild'
tinyMCELang['lang_insert_image_mouseover'] = 'n&auml;r pekaren &auml;r &ouml;ver';
tinyMCELang['lang_insert_image_mouseout'] = 'n&auml;r pekaren &auml;r utanf&ouml;r';
