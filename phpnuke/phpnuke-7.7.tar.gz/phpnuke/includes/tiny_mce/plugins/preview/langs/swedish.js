// SE lang variables

tinyMCELang['lang_preview_desc'] = 'F�rhandsgranska';
