// UK lang variables

tinyMCELang['lang_preview_desc'] = 'Pr�-visualiza��o';
