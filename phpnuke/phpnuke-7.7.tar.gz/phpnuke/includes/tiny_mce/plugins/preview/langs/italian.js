// IT lang variables

tinyMCELang['lang_preview_desc'] = 'Anteprima';
