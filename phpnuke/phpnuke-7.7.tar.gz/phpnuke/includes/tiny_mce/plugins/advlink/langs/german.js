// DE lang variables

tinyMCELang['lang_insert_link_target_same'] = 'Im selben Frame &ouml;ffnen';
tinyMCELang['lang_insert_link_target_parent'] = 'Im dar&uuml;ber liegenden Frame &ouml;ffnen';
tinyMCELang['lang_insert_link_target_top']= 'Im obersten Frame &ouml;ffnen';
tinyMCELang['lang_insert_link_target_blank']= 'In einem neuen Fenster &ouml;ffnen';
tinyMCELang['lang_insert_link_target_named']= '&Ouml;ffnen im Fenster/Frame';
tinyMCELang['lang_insert_link_popup'] = 'JS-Popup';
tinyMCELang['lang_insert_link_popup_url'] = 'Popup URL';
tinyMCELang['lang_insert_link_popup_name']= 'Fenstername';
tinyMCELang['lang_insert_link_popup_return']= 'mit \'return false\'';
tinyMCELang['lang_insert_link_popup_scrollbars']= 'Scrollbars anzeigen';
tinyMCELang['lang_insert_link_popup_statusbar'] = 'Statusbar anzeigen';
tinyMCELang['lang_insert_link_popup_toolbar'] = 'Toolbars anzeigen';
tinyMCELang['lang_insert_link_popup_menubar'] = 'Menu anzeigen';
tinyMCELang['lang_insert_link_popup_location']= 'Adresszeile anzeigen';
tinyMCELang['lang_insert_link_popup_resizable'] = 'Gr&ouml;&szlig;e &auml;nderbar';
tinyMCELang['lang_insert_link_popup_size']= 'Gr&ouml;&szlig;e';
tinyMCELang['lang_insert_link_popup_position']= 'Position (X/Y)';
tinyMCELang['lang_insert_link_popup_missingtarget'] = 'Bitte geben Sie einen Namen f&uuml;r das Ziel an oder w&auml;hlen Sie eine andere Option.';
