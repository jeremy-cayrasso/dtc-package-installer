// IT lang variables

tinyMCELang['lang_insertdate_desc'] = 'Inserisci data';
tinyMCELang['lang_inserttime_desc'] = 'Inserisci ora';
tinyMCELang['lang_inserttime_months_long'] = new Array("Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre");
tinyMCELang['lang_inserttime_months_short'] = new Array("Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic");
tinyMCELang['lang_inserttime_day_long'] = new Array("Domenica", "Luned�", "Marted�", "Mercoled�", "Gioved�", "Venerd�", "Sabato", "Domenica");
tinyMCELang['lang_inserttime_day_short'] = new Array("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun");
