-- $Horde: horde/scripts/sql/horde_sessionhandler.oci8.sql,v 1.2 2004/09/21 03:34:06 chuck Exp $

CREATE TABLE horde_sessionhandler (
    session_id             VARCHAR(32) NOT NULL,
    session_lastmodified   INT NOT NULL,
    session_data           BLOB,
--
    PRIMARY KEY (session_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON horde_sessionhandler TO horde;
