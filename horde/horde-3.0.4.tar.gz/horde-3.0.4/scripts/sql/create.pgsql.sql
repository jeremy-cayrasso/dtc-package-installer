-- $Horde: horde/scripts/sql/create.pgsql.sql,v 1.1 2004/09/18 17:20:59 chuck Exp $
--
-- Uncomment the ALTER line below, and change the password.  Then run as:
--
-- $ psql -d template1 -f pgsql_create.sql

CREATE DATABASE horde;

CREATE USER horde;

-- ALTER USER horde WITH PASSWORD 'pass';
