-- $Horde: horde/scripts/sql/horde_users.sql,v 1.2 2004/09/21 03:34:06 chuck Exp $

CREATE TABLE horde_users (
    user_uid   VARCHAR(255) NOT NULL,
    user_pass  VARCHAR(32) NOT NULL,
--
    PRIMARY KEY (user_uid)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON horde_users TO horde;
