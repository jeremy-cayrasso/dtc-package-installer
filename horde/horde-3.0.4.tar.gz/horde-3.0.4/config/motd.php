<!-- This file contains any "Message Of The Day" Type information -->
<!-- It will be included below the log-in form on the login page. -->

<br />
<table width="100%"><tr><td align="center"><img src="themes/graphics/horde-power1.png" alt="Powered by Horde" /></td></tr></table>

