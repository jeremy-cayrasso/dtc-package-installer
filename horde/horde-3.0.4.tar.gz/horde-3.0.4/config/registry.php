<?php
/**
 * registry.php -- Horde application registry.
 *
 * $Horde: horde/config/registry.php.dist,v 1.255.2.2 2004/12/24 01:05:12 chuck Exp $
 *
 * This configuration file is used by Horde to determine which Horde
 * applications are installed and where, as well as how they interact.
 *
 * Application registry
 * --------------------
 * The following settings register installed Horde applications.
 * By default, Horde assumes that the application directories live
 * inside the horde directory.
 *
 * Attribute     Type     Description
 * ---------     ----     -----------
 * fileroot      string   The base filesystem path for the module's files.
 * webroot       string   The base URI for the module.
 * jsuri         string   The base URI for static javascript files.
 * jsfs          string   The base filesystem path for static javascript files.
 * themesuri     string   The base URI for the themes.
 * themesfs      string   The base file system directory for the themes.
 * icon          string   The URI for an icon to show in menus for the module.
 *                        Setting this will override the default theme-based
 *                        logic in the code.
 * name          string   The name used in menus and descriptions for a module
 * status        string   'inactive', 'hidden', 'notoolbar', 'heading',
 *                        'block', 'admin', or 'active'.
 * provides      string   Service types the module provides.
 * initial_page  string   The initial (default) page (filename) for the module.
 * templates     string   The filesystem path to the templates directory.
 * menu_parent   string   The name of the 'heading' group that this app should
 *                        show up under.
 * target        string   The (optional) target frame for the link.
 * url           string   The (optional) URL of 'heading' entries.
 */

// We try to automatically determine the proper webroot for Horde
// here. This still assumes that applications live under horde/. If
// this results in incorrect results for you, simply change the two
// uses of the $webroot variable in the 'horde' stanza below.
//
// Note for Windows users: the below assumes that your PHP_SELF
// variable uses forward slashes. If it does not, you'll have to tweak
// this.
if (isset($_SERVER['PHP_SELF'])) {
    $webroot = strstr(dirname(__FILE__), '/' . array_shift(preg_split(';/;', $_SERVER['PHP_SELF'], 2, PREG_SPLIT_NO_EMPTY)));
    if ($webroot !== false) {
        $webroot = preg_replace(';/config$;', '', $webroot);
    } else {
        $webroot = '/horde';
    }
} else {
    $webroot = '/horde';
}

$this->applications['horde'] = array(
    'fileroot' => dirname(__FILE__) . '/..',
    'webroot' => $webroot,
    'initial_page' => 'login.php',
    'name' => _("Horde"),
    'status' => 'active',
    'templates' => dirname(__FILE__) . '/../templates',
    'provides' => 'horde'
);

$this->applications['imp'] = array(
    'fileroot' => dirname(__FILE__) . '/../imp',
    'webroot' => $this->applications['horde']['webroot'] . '/imp',
    'name' => _("Mail"),
    'status' => 'active',
    'provides' => 'mail',
);

$this->applications['imp-folders'] = array(
    'status' => 'block',
    'app' => 'imp',
    'blockname' => 'tree_folders',
    'menu_parent' => 'imp',
);

$this->applications['ingo'] = array(
    'fileroot' => dirname(__FILE__) . '/../ingo',
    'webroot' => $this->applications['horde']['webroot'] . '/ingo',
    'name' => _("Filters"),
    'status' => 'active',
    'provides' => array('mail/blacklistFrom', 'mail/showBlacklist', 'mail/whitelistFrom', 'mail/showWhitelist', 'mail/applyFilters', 'mail/canApplyFilters', 'mail/showFilters'),
    'menu_parent' => 'imp'
);

$this->applications['sam'] = array(
    'fileroot' => dirname(__FILE__) . '/../sam',
    'webroot' => $this->applications['horde']['webroot'] . '/sam',
    'name' => _("Spam"),
    'status' => 'inactive',
    // Uncomment this line if you want Sam to handle the blacklist
    // filter instead of Ingo:
    // 'provides' => array('mail/blacklistFrom', 'mail/showBlacklist', 'mail/whitelistFrom', 'mail/showWhitelist'),
    'menu_parent' => 'imp'
);

$this->applications['troll'] = array(
    'fileroot' => dirname(__FILE__) . '/../troll',
    'webroot' => $this->applications['horde']['webroot'] . '/troll',
    'name' => _("Newsgroups"),
    'status' => 'inactive',
    'menu_parent' => 'imp'
);

$this->applications['vilma'] = array(
    'fileroot' => dirname(__FILE__) . '/../vilma',
    'webroot' => $this->applications['horde']['webroot'] . '/vilma',
    'name' => _("Mail Admin"),
    'status' => 'inactive',
    'menu_parent' => 'imp'
);

$this->applications['mimp'] = array(
    'fileroot' => dirname(__FILE__) . '/../mimp',
    'webroot' => $this->applications['horde']['webroot'] . '/mimp',
    'name' => _("Mobile Mail"),
    'status' => 'inactive'
);

$this->applications['organizing'] = array(
    'name' => _("Organizing"),
    'status' => 'heading',
);

$this->applications['turba'] = array(
    'fileroot' => dirname(__FILE__) . '/../turba',
    'webroot' => $this->applications['horde']['webroot'] . '/turba',
    'name' => _("Address Book"),
    'status' => 'active',
    'provides' => array('contacts', 'clients'),
    'menu_parent' => 'organizing'
);

$this->applications['kronolith'] = array(
    'fileroot' => dirname(__FILE__) . '/../kronolith',
    'webroot' => $this->applications['horde']['webroot'] . '/kronolith',
    'name' => _("Calendar"),
    'status' => 'active',
    'provides' => 'calendar',
    'menu_parent' => 'organizing'
);

$this->applications['kronolith-menu'] = array(
    'status' => 'block',
    'app' => 'kronolith',
    'blockname' => 'tree_menu',
    'menu_parent' => 'kronolith',
);

$this->applications['mnemo'] = array(
    'fileroot' => dirname(__FILE__) . '/../mnemo',
    'webroot' => $this->applications['horde']['webroot'] . '/mnemo',
    'name' => _("Notes"),
    'status' => 'active',
    'provides' => 'notes',
    'menu_parent' => 'organizing'
);

$this->applications['nag'] = array(
    'fileroot' => dirname(__FILE__) . '/../nag',
    'webroot' => $this->applications['horde']['webroot'] . '/nag',
    'name' => _("Tasks"),
    'status' => 'active',
    'provides' => 'tasks',
    'menu_parent' => 'organizing'
);

$this->applications['genie'] = array(
    'fileroot' => dirname(__FILE__) . '/../genie',
    'webroot' => $this->applications['horde']['webroot'] . '/genie',
    'name' => _("Wishlists"),
    'status' => 'inactive',
    'provides' => 'wishlist',
    'menu_parent' => 'organizing'
);

$this->applications['trean'] = array(
    'fileroot' => dirname(__FILE__) . '/../trean',
    'webroot' => $this->applications['horde']['webroot'] . '/trean',
    'name' => _("Bookmarks"),
    'status' => 'inactive',
    'provides' => 'bookmarks',
    'menu_parent' => 'organizing'
);

$this->applications['devel'] = array(
    'name' => _("Development"),
    'status' => 'heading',
);

$this->applications['chora'] = array(
    'fileroot' => dirname(__FILE__) . '/../chora',
    'webroot' => $this->applications['horde']['webroot'] . '/chora',
    'name' => _("Version Control"),
    'status' => 'active',
    'menu_parent' => 'devel'
);

$this->applications['babel'] = array(
    'fileroot' => dirname(__FILE__) . '/../babel',
    'webroot' => $this->applications['horde']['webroot'] . '/babel',
    'name' => _("i18n"),
    'status' => 'inactive',
    'menu_parent' => 'devel'
);

$this->applications['thor'] = array(
    'fileroot' => dirname(__FILE__) . '/../thor',
    'webroot' => $this->applications['horde']['webroot'] . '/thor',
    'name' => _("Projects"),
    'status' => 'inactive',
    'provides' => 'projects',
    'menu_parent' => 'devel'
);

$this->applications['whups'] = array(
    'fileroot' => dirname(__FILE__) . '/../whups',
    'webroot' => $this->applications['horde']['webroot'] . '/whups',
    'name' => _("Tickets"),
    'status' => 'inactive',
    'provides' => 'tickets',
    'menu_parent' => 'devel'
);

$this->applications['luxor'] = array(
    'fileroot' => dirname(__FILE__) . '/../luxor',
    'webroot' => $this->applications['horde']['webroot'] . '/luxor',
    'name' => _("X-Ref"),
    'status' => 'inactive',
    'menu_parent' => 'devel'
);

$this->applications['nic'] = array(
    'fileroot' => dirname(__FILE__) . '/../nic',
    'webroot' => $this->applications['horde']['webroot'] . '/nic',
    'name' => _("Network"),
    'status' => 'inactive',
    'provides' => 'net',
    'menu_parent' => 'devel'
);

$this->applications['info'] = array(
    'name' => _("Information"),
    'status' => 'heading',
);

$this->applications['mottle'] = array(
    'fileroot' => dirname(__FILE__) . '/../mottle',
    'webroot' => $this->applications['horde']['webroot'] . '/mottle',
    'name' => _("MOTD"),
    'status' => 'inactive',
    'menu_parent' => 'info'
);

$this->applications['jonah'] = array(
    'fileroot' => dirname(__FILE__) . '/../jonah',
    'webroot' => $this->applications['horde']['webroot'] . '/jonah',
    'name' => _("News"),
    'status' => 'inactive',
    'provides' => 'news',
    'menu_parent' => 'info'
);

$this->applications['occam'] = array(
    'fileroot' => dirname(__FILE__) . '/../occam',
    'webroot' => $this->applications['horde']['webroot'] . '/occam',
    'name' => _("Courses"),
    'status' => 'inactive',
    'menu_parent' => 'info'
);

$this->applications['goops'] = array(
    'fileroot' => dirname(__FILE__) . '/../goops',
    'webroot' => $this->applications['horde']['webroot'] . '/goops',
    'name' => _("Search Engines"),
    'status' => 'inactive',
    'menu_parent' => 'info'
);

$this->applications['klutz'] = array(
    'fileroot' => dirname(__FILE__) . '/../klutz',
    'webroot' => $this->applications['horde']['webroot'] . '/klutz',
    'name' => _("Comics"),
    'status' => 'inactive',
    'provides' => 'comics',
    'menu_parent' => 'info'
);

$this->applications['orator'] = array(
    'fileroot' => dirname(__FILE__) . '/../orator',
    'webroot' => $this->applications['horde']['webroot'] . '/orator',
    'name' => _("Presentations"),
    'status' => 'inactive',
    'menu_parent' => 'info'
);

$this->applications['office'] = array(
    'name' => _("Office"),
    'status' => 'heading',
);

$this->applications['hermes'] = array(
    'fileroot' => dirname(__FILE__) . '/../hermes',
    'webroot' => $this->applications['horde']['webroot'] . '/hermes',
    'name' => _("Time Tracking"),
    'status' => 'inactive',
    'menu_parent' => 'office',
    'provides' => 'time'
);

$this->applications['juno'] = array(
    'fileroot' => dirname(__FILE__) . '/../juno',
    'webroot' => $this->applications['horde']['webroot'] . '/juno',
    'name' => _("Accounting"),
    'status' => 'inactive',
    'menu_parent' => 'office'
);

$this->applications['sesha'] = array(
    'fileroot' => dirname(__FILE__) . '/../sesha',
    'webroot' => $this->applications['horde']['webroot'] . '/sesha',
    'name' => _("Inventory"),
    'status' => 'inactive',
    'menu_parent' => 'office',
);

$this->applications['myaccount'] = array(
    'name' => _("My Account"),
    'status' => 'heading',
);

$this->applications['accounts'] = array(
    'fileroot' => dirname(__FILE__) . '/../accounts',
    'webroot' => $this->applications['horde']['webroot'] . '/accounts',
    'name' => _("My Account"),
    'status' => 'inactive',
    'menu_parent' => 'myaccount',
);

$this->applications['gollem'] = array(
    'fileroot' => dirname(__FILE__) . '/../gollem',
    'webroot' => $this->applications['horde']['webroot'] . '/gollem',
    'name' => _("File Manager"),
    'status' => 'inactive',
    'menu_parent' => 'myaccount',
    'provides' => 'files',
);

$this->applications['forwards'] = array(
    'fileroot' => dirname(__FILE__) . '/../forwards',
    'webroot' => $this->applications['horde']['webroot'] . '/forwards',
    'name' => _("Forwards"),
    'status' => 'inactive',
    'provides' => 'forwards',
    'menu_parent' => 'myaccount',
);

$this->applications['passwd'] = array(
    'fileroot' => dirname(__FILE__) . '/../passwd',
    'webroot' => $this->applications['horde']['webroot'] . '/passwd',
    'name' => _("Password"),
    'status' => 'inactive',
    'menu_parent' => 'myaccount'
);

$this->applications['jeta'] = array(
    'fileroot' => dirname(__FILE__) . '/../jeta',
    'webroot' => $this->applications['horde']['webroot'] . '/jeta',
    'name' => _("SSH"),
    'status' => 'inactive',
    'menu_parent' => 'myaccount'
);

$this->applications['vacation'] = array(
    'fileroot' => dirname(__FILE__) . '/../vacation',
    'webroot' => $this->applications['horde']['webroot'] . '/vacation',
    'name' => _("Vacation"),
    'status' => 'inactive',
    'provides' => 'vacation',
    'menu_parent' => 'myaccount'
);

$this->applications['website'] = array(
    'name' => _("Web Site"),
    'status' => 'heading',
);

$this->applications['giapeto'] = array(
    'fileroot' => dirname(__FILE__) . '/../giapeto',
    'webroot' => $this->applications['horde']['webroot'] . '/giapeto',
    'name' => _("CMS"),
    'status' => 'inactive',
    'provides' => 'cms',
    'menu_parent' => 'website'
);

$this->applications['midas'] = array(
    'fileroot' => dirname(__FILE__) . '/../midas',
    'webroot' => $this->applications['horde']['webroot'] . '/midas',
    'name' => _("Ads"),
    'status' => 'inactive',
    'menu_parent' => 'website'
);

$this->applications['agora'] = array(
    'fileroot' => dirname(__FILE__) . '/../agora',
    'webroot' => $this->applications['horde']['webroot'] . '/agora',
    'name' => _("Forums"),
    'status' => 'inactive',
    'provides' => 'forums',
    'menu_parent' => 'website'
);

$this->applications['odin'] = array(
    'fileroot' => dirname(__FILE__) . '/../odin',
    'webroot' => $this->applications['horde']['webroot'] . '/odin',
    'name' => _("Data"),
    'status' => 'inactive',
    'menu_parent' => 'website'
);

$this->applications['ulaform'] = array(
    'fileroot' => dirname(__FILE__) . '/../ulaform',
    'webroot' => $this->applications['horde']['webroot'] . '/ulaform',
    'name' => _("Forms"),
    'status' => 'inactive',
    'menu_parent' => 'website'
);

$this->applications['volos'] = array(
    'fileroot' => dirname(__FILE__) . '/../volos',
    'webroot' => $this->applications['horde']['webroot'] . '/volos',
    'name' => _("Guestbook"),
    'status' => 'inactive',
    'menu_parent' => 'website'
);

$this->applications['ansel'] = array(
    'fileroot' => dirname(__FILE__) . '/../ansel',
    'webroot' => $this->applications['horde']['webroot'] . '/ansel',
    'name' => _("Photos"),
    'status' => 'inactive',
    'provides' => 'images',
    'menu_parent' => 'website'
);

$this->applications['scry'] = array(
    'fileroot' => dirname(__FILE__) . '/../scry',
    'webroot' => $this->applications['horde']['webroot'] . '/scry',
    'name' => _("Polls"),
    'status' => 'inactive',
    'provides' => 'polls',
    'menu_parent' => 'website'
);

$this->applications['rakim'] = array(
    'fileroot' => dirname(__FILE__) . '/../rakim',
    'webroot' => $this->applications['horde']['webroot'] . '/rakim',
    'name' => _("Support"),
    'status' => 'inactive',
    'menu_parent' => 'website'
);

$this->applications['merk'] = array(
    'fileroot' => dirname(__FILE__) . '/../merk',
    'webroot' => $this->applications['horde']['webroot'] . '/merk',
    'name' => _("Shopping"),
    'status' => 'inactive',
    'menu_parent' => 'website'
);

$this->applications['swoosh'] = array(
    'fileroot' => dirname(__FILE__) . '/../swoosh',
    'webroot' => $this->applications['horde']['webroot'] . '/swoosh',
    'name' => _("SMS Messaging"),
    'status' => 'inactive',
    'provides' => 'sms',
    'menu_parent' => 'website'
);

$this->applications['wicked'] = array(
    'fileroot' => dirname(__FILE__) . '/../wicked',
    'webroot' => $this->applications['horde']['webroot'] . '/wicked',
    'name' => _("Wiki"),
    'status' => 'inactive',
    'provides' => 'wiki',
    'menu_parent' => 'website'
);
