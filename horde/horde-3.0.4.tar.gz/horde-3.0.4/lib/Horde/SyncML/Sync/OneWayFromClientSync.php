<?php

include_once 'Horde/SyncML/Sync.php';

/**
 * No need to run anything at begining or end of sync, Sync will
 * handle this.
 *
 * $Horde: framework/SyncML/SyncML/Sync/OneWayFromClientSync.php,v 1.6.10.1 2005/01/03 12:19:15 jan Exp $
 *
 * Copyright 2003-2005 Anthony Mills <amills@pyramid6.com>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Anthony Mills <amills@pyramid6.com>
 * @version $Revision: 1.6.10.1 $
 * @since   Horde 3.0
 * @package Horde_SyncML
 */
class Horde_SyncML_Sync_OneWayFromClientSync extends Horde_SyncML_Sync {

}
