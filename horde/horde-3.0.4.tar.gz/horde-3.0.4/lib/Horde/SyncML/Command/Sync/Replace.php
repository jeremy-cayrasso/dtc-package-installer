<?php

include_once 'Horde/SyncML/Command/Sync/SyncElement.php';

/**
 * $Horde: framework/SyncML/SyncML/Command/Sync/Replace.php,v 1.9.10.1 2005/01/03 12:19:15 jan Exp $
 *
 * Copyright 2003-2005 Anthony Mills <amills@pyramid6.com>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 *
 * @author  Anthony Mills <amills@pyramid6.com>
 * @version $Revision: 1.9.10.1 $
 * @since   Horde 3.0
 * @package Horde_SyncML
 */
class Horde_SyncML_Command_Sync_Replace extends Horde_SyncML_Command_Sync_SyncElement {

    function output($currentCmdID, &$output)
    {
        $status = &new Horde_SyncML_Command_Status(RESPONSE_OK, 'Replace');
        $status->setCmdRef($this->_cmdID);

        if (isset($this->_luid)) {
            $status->setSourceRef($this->_luid);
        }

        return $status->output($currentCmdID, $output);
    }

}
