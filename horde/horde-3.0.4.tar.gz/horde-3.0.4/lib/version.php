<?php define('HORDE_VERSION', '3.0.4') ?>
