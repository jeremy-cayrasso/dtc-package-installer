/**
 * Horde Popup JavaScript.
 *
 * Provides the javascript to open popup windows.
 *
 * $Horde: horde/js/popup.js,v 1.2.10.2 2005/01/21 18:19:15 chuck Exp $
 *
 * See the enclosed file COPYING for license information (LGPL). If you did not
 * receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */
function popup(url, width, height)
{
    if (!width) {
        width = 600;
    }
    if (!height) {
        height = 500;
    }

    var now = new Date();
    var name = now.getTime();
    param = "toolbar=no,location=no,status=yes,scrollbars=yes,resizable=yes,width=" + width + ",height=" + height + ",left=0,top=0";
    eval("win = window.open(url, name, param)");
    if (!eval("win.name")) {
        eval("win.name = name");
    }
    if (!eval("win.opener")) {
        eval("win.opener = self");
    }

    return win;
}
