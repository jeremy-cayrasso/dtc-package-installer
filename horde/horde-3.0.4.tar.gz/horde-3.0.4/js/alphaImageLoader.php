<?php
/**
 * $Horde: horde/js/alphaImageLoader.php,v 1.2.8.1 2005/01/03 12:25:39 jan Exp $
 *
 * Copyright 2004-2005 Charles J. Hagenbuch <chuck@horde.org>
 *
 * See the enclosed file COPYING for license information (LGPL). If you
 * did not receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */

@define('HORDE_BASE', dirname(__FILE__) . '/..');
require_once HORDE_BASE . '/lib/core.php';

$registry = &Registry::singleton(HORDE_SESSION_NONE);

/* This should be cached. */
$mod_gmt = gmdate('D, d M Y H:i:s', filemtime(__FILE__)) . ' GMT';
header('Last-Modified: ' . $mod_gmt);
header('Cache-Control: public, max-age=86400');
header('Content-Type: text/x-component');

?>
<public:component>
<public:attach event="onpropertychange" for="element" onEvent="propertyChanged()" />
<script language="JavaScript">

var needHack = needHack();
var transparentImage = "<?php echo $registry->getImageDir('horde') ?>/blank.gif";

pngHack();

function propertyChanged()
{
    if (event.propertyName == "src") {
        pngHack();
    }
}

function pngHack()
{
    if (!needHack) {
        return;
    }

    var w = element.width;
    var h = element.height;
    var src = element.src;
    if (src.indexOf(transparentImage) != -1) {
        // Already fixed.
        return;
    }

    if (src.indexOf("png") == -1) {
        element.runtimeStyle.filter = "";
        return;
    }

    element.src = transparentImage;
    element.width = w;
    element.height = h;
    element.runtimeStyle.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + src + "',sizingMethod='scale')";
}

function needHack()
{
    var pos = navigator.userAgent.indexOf("MSIE ");
    if (pos == -1) {
        return false;
    }

    var version = navigator.userAgent.substring(pos + 5);

    return (((version.indexOf("5.5") == 0) || (version.indexOf("6") == 0)) && (navigator.platform == ("Win32")));
}

</script>
</public:component>
