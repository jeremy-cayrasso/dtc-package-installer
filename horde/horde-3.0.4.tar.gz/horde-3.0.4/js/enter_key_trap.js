/**
 * Javascript to trap for the enter key.
 *
 * $Horde: horde/js/enter_key_trap.js,v 1.2 2004/10/19 19:08:53 chuck Exp $
 *
 * See the enclosed file COPYING for license information (LGPL). If you did not
 * receive this file, see http://www.fsf.org/copyleft/lgpl.html.
 */

function enter_key_trap(e)
{
    var keyPressed;

    if (document.layers) {
        keyPressed = String.fromCharCode(e.which);
    } else if (document.all) {
        keyPressed = String.fromCharCode(window.event.keyCode);
    } else if (document.getElementById) {
        keyPressed = String.fromCharCode(e.keyCode);
    }

    return (keyPressed == "\r" || keyPressed == "\n");
}
