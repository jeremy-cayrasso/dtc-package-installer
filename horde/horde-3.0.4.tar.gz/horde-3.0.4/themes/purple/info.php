<?php
/**
 * $Horde: horde/themes/purple/info.php,v 1.1 2004/11/25 02:04:54 chuck Exp $
 */

$theme_name = _("Purple Horde");
