<?php
/**
 * $Horde: horde/themes/grey/info.php,v 1.1 2004/10/17 19:33:36 mdjukic Exp $
 */

$theme_name = _("Grey");
