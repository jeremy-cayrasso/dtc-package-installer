<?php
/**
 * $Horde: horde/themes/barbie/info.php,v 1.1 2004/10/17 19:33:33 mdjukic Exp $ ?>
 */

$theme_name = _("Barbie");
