<?php
/**
 * $Horde: horde/themes/azur/info.php,v 1.1 2004/10/17 19:33:33 mdjukic Exp $ ?>
 *
 * @author Joost De Cock <joost@decock.org>
 */

$theme_name = _("Azur");
