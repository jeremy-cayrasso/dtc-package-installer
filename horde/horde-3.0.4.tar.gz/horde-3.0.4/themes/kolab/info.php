<?php
/**
 * Kolab theme by Stuart Binge <s.binge@codefusion.co.za>
 * Derived from the 'Light Blue' theme.
 *
 * $Horde: horde/themes/kolab/info.php,v 1.1 2004/10/17 19:33:36 mdjukic Exp $
 */

$theme_name = _("Kolab");
