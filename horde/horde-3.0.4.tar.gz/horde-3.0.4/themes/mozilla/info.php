<?php
/**
 * $Horde: horde/themes/mozilla/info.php,v 1.1 2004/10/17 19:33:37 mdjukic Exp $
 */

$theme_name = _("Mozilla");
