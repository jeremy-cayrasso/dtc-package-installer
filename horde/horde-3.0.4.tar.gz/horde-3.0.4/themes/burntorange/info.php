<?php
/**
 * Theme by: Eric Jon Rostetter <eric.rostetter@physics.utexas.edu>
 * Please contact the theme's author for any missing style.
 *
 * $Horde: horde/themes/burntorange/info.php,v 1.1 2004/10/17 19:33:35 mdjukic Exp $
 */

$theme_name = _("Burnt Orange");
