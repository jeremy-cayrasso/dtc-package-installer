<?php
/**
 * $Horde: horde/themes/bluemoon/info.php,v 1.1 2004/10/17 19:33:34 mdjukic Exp $
 */

$theme_name = _("Blue Moon");
