<?php
/**
 * $Horde: horde/themes/brown/info.php,v 1.1 2004/10/17 19:33:34 mdjukic Exp $
 */

$theme_name = _("Brown");
