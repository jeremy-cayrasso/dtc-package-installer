<?php
/**
 * $Horde: horde/themes/camouflage/info.php,v 1.1 2004/10/17 19:33:35 mdjukic Exp $
 */

$theme_name = _("Camouflage");
