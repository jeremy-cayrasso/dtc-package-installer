<?php
/*
  $Id: product_reviews_info.php,v 1.7 2003/07/08 16:45:36 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Comentarios');
define('HEADING_TITLE', ' %s Comentarios');
define('SUB_TITLE_PRODUCT', 'Producto:');
define('SUB_TITLE_FROM', 'De:');
define('SUB_TITLE_DATE', 'Fecha:');
define('SUB_TITLE_REVIEW', 'Comentario:');
define('SUB_TITLE_RATING', 'Evaluaci&oacute;n:');
define('TEXT_OF_5_STARS', '%s de 5 Estrellas!');
define('TEXT_CLICK_TO_ENLARGE', 'Haga Click para agrandar');
?>