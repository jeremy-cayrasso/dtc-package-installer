<?php
/*
  $Id: checkout_shipping_address.php,v 1.4 2003/07/08 16:45:36 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Realizar Compra');
define('NAVBAR_TITLE_2', 'Cambiar Direcci&oacute;n de Entrega');

define('HEADING_TITLE', 'Datos del Env&iacute;o');

define('TABLE_HEADING_SHIPPING_ADDRESS', 'Direcci&oacute;n de Entrega');
define('TEXT_SELECTED_SHIPPING_DESTINATION', 'Esta es la direcci&oacute;n de entrega seleccionada para el env&iacute;o de los productos de su pedido.');
define('TITLE_SHIPPING_ADDRESS', 'Direcci&oacute;n de Entrega:');

define('TABLE_HEADING_ADDRESS_BOOK_ENTRIES', 'Libreta de Direcciones');
define('TEXT_SELECT_OTHER_SHIPPING_DESTINATION', 'Seleccione otra direcci&oacute;n de entrega para su pedido si quiere que sea entregado en un sitio diferente.');
define('TITLE_PLEASE_SELECT', 'Seleccione');

define('TABLE_HEADING_NEW_SHIPPING_ADDRESS', 'Nueva Direcci&oacute;n');
define('TEXT_CREATE_NEW_SHIPPING_ADDRESS', 'Use el formulario siguiente para crear una direcci&oacute;n nueva en su libreta y usarla como direcci&oacute;n de entrega para su pedido.');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Continuar con el Proceso de Compra');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'para seleccionar la forma de envio.');
?>
