<?php
/*
  $Id: account_edit.php,v 1.8 2003/05/19 20:17:50 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'My Account');
define('NAVBAR_TITLE_2', 'Edit Account');

define('HEADING_TITLE', 'My Account Information');

define('MY_ACCOUNT_TITLE', 'My Account');

define('SUCCESS_ACCOUNT_UPDATED', 'Your account has been successfully updated.');
?>
