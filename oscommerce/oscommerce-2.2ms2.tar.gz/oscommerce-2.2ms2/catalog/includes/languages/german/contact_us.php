<?php
/*
  $Id: contact_us.php,v 1.7 2002/04/17 15:57:07 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Kontakt');
define('NAVBAR_TITLE', 'Kontakt');
define('TEXT_SUCCESS', 'Ihre Anfrage wurde erfolgreich an den Vertrieb gesendet.');
define('EMAIL_SUBJECT', 'Anfrage von ' . STORE_NAME);

define('ENTRY_NAME', 'Vollst&auml;ndiger Name:');
define('ENTRY_EMAIL', 'eMail-Adresse:');
define('ENTRY_ENQUIRY', 'Anfrage:');
?>