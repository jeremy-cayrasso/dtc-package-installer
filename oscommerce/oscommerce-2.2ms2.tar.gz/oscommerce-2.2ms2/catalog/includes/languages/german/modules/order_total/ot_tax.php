<?php
/*
  $Id: ot_tax.php,v 1.3 2003/07/11 09:04:23 jan0815 Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_TAX_TITLE', 'MwSt.');
  define('MODULE_ORDER_TOTAL_TAX_DESCRIPTION', 'Mehrwertsteuer');
?>
